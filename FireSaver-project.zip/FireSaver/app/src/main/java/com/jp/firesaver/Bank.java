package com.jp.firesaver;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The media bank: every photo/video the app knows about, kept on the device between launches.
 * Also stores favourites, the list of deleted media (never shown again) and the 24h description cache.
 */
final class Bank {
    private static final int MAX_ITEMS = 1200;
    private static final int MAX_DELETED = 20000;
    private static final int MAX_DESCS = 300;
    private static final long DESC_TTL_MS = 24L * 60 * 60 * 1000;

    static final class Desc {
        final String text;
        final boolean ai;
        final long ts;
        Desc(String text, boolean ai, long ts) { this.text = text; this.ai = ai; this.ts = ts; }
    }

    private static Bank instance;

    static synchronized Bank get(Context ctx) {
        if (instance == null) instance = new Bank(ctx.getApplicationContext());
        return instance;
    }

    private final File bankFile;
    private final File descFile;
    private final List<Media> items = new ArrayList<>();
    private final Map<String, Media> index = new HashMap<>();
    private final LinkedHashSet<String> deleted = new LinkedHashSet<>();
    private final Map<String, Desc> descs = new HashMap<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private Bank(Context ctx) {
        File dir = ctx.getFilesDir();
        bankFile = new File(dir, "bank.json");
        descFile = new File(dir, "descriptions.json");
        load();
    }

    // ---------- counters ----------

    synchronized int photos() {
        int n = 0;
        for (Media m : items) if (!m.video) n++;
        return n;
    }

    synchronized int videos() {
        int n = 0;
        for (Media m : items) if (m.video) n++;
        return n;
    }

    synchronized int total() { return items.size(); }

    synchronized boolean contains(Media m) { return m != null && index.get(m.src) == m; }

    synchronized List<Media> snapshot() { return new ArrayList<>(items); }

    // ---------- changes ----------

    /** Adds new media (already known or deleted ones are ignored). Returns how many were added. */
    synchronized int addAll(List<Media> list) {
        int n = 0;
        for (Media m : list) {
            if (m == null || m.src == null || m.src.isEmpty()) continue;
            if (deleted.contains(m.src) || index.containsKey(m.src)) continue;
            items.add(m);
            index.put(m.src, m);
            n++;
        }
        if (n > 0) {
            evictIfNeeded();
            saveBank();
        }
        return n;
    }

    /** Removes the media from the bank for good (it will never come back). */
    synchronized void delete(Media m) {
        Media cur = index.remove(m.src);
        if (cur != null) items.remove(cur);
        descs.remove(m.src);
        deleted.add(m.src);
        while (deleted.size() > MAX_DELETED) {
            Iterator<String> it = deleted.iterator();
            it.next();
            it.remove();
        }
        saveBank();
        saveDescs();
    }

    /** Returns the new favourite state. */
    synchronized boolean toggleFav(Media m) {
        Media cur = index.get(m.src);
        if (cur == null) return false;
        cur.fav = !cur.fav;
        m.fav = cur.fav;
        saveBank();
        return cur.fav;
    }

    /** A link that is really gone: after 3 failures it leaves the bank (but is not blacklisted). */
    synchronized void recordFail(Media m) {
        Media cur = index.get(m.src);
        if (cur == null) return;
        cur.fails++;
        if (cur.fails >= 3) {
            index.remove(cur.src);
            items.remove(cur);
            descs.remove(cur.src);
        }
        saveBank();
    }

    synchronized void recordOk(Media m) {
        Media cur = index.get(m.src);
        if (cur != null && cur.fails > 0) {
            cur.fails = 0;
            saveBank();
        }
    }

    private void evictIfNeeded() {
        int extra = items.size() - MAX_ITEMS;
        if (extra <= 0) return;
        List<Media> candidates = new ArrayList<>();
        for (Media m : items) if (!m.fav) candidates.add(m);
        Collections.sort(candidates, new Comparator<Media>() {
            @Override public int compare(Media a, Media b) { return Long.compare(a.added, b.added); }
        });
        for (int i = 0; i < extra && i < candidates.size(); i++) {
            Media m = candidates.get(i);
            items.remove(m);
            index.remove(m.src);
            descs.remove(m.src);
        }
    }

    // ---------- description cache (24h) ----------

    synchronized Desc getDesc(String src) {
        Desc d = descs.get(src);
        if (d == null) return null;
        if (System.currentTimeMillis() - d.ts > DESC_TTL_MS) {
            descs.remove(src);
            return null;
        }
        return d;
    }

    synchronized void putDesc(String src, String text, boolean ai) {
        descs.put(src, new Desc(text, ai, System.currentTimeMillis()));
        while (descs.size() > MAX_DESCS) {
            String oldest = null;
            long ts = Long.MAX_VALUE;
            for (Map.Entry<String, Desc> e : descs.entrySet()) {
                if (e.getValue().ts < ts) { ts = e.getValue().ts; oldest = e.getKey(); }
            }
            if (oldest == null) break;
            descs.remove(oldest);
        }
        saveDescs();
    }

    // ---------- persistence ----------

    private void load() {
        try {
            if (bankFile.exists()) {
                JSONObject o = new JSONObject(read(bankFile));
                JSONArray a = o.optJSONArray("items");
                if (a != null) {
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject j = a.getJSONObject(i);
                        String s = j.optString("s", "");
                        if (s.isEmpty() || index.containsKey(s)) continue;
                        Media m = new Media(s, j.optInt("v", 0) == 1, j.optString("o", ""));
                        m.title = j.optString("t", "");
                        m.desc = j.optString("d", "");
                        m.tags = j.optString("g", "");
                        m.added = j.optLong("a", 0);
                        m.fails = j.optInt("f", 0);
                        m.fav = j.optInt("fav", 0) == 1;
                        items.add(m);
                        index.put(s, m);
                    }
                }
                JSONArray d = o.optJSONArray("del");
                if (d != null) for (int i = 0; i < d.length(); i++) deleted.add(d.getString(i));
            }
        } catch (Exception ignored) { }
        try {
            if (descFile.exists()) {
                JSONArray a = new JSONArray(read(descFile));
                long now = System.currentTimeMillis();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject j = a.getJSONObject(i);
                    long ts = j.optLong("ts", 0);
                    if (now - ts > DESC_TTL_MS) continue;
                    descs.put(j.getString("s"), new Desc(j.optString("t", ""), j.optInt("ai", 0) == 1, ts));
                }
            }
        } catch (Exception ignored) { }
    }

    private void saveBank() {
        try {
            JSONArray a = new JSONArray();
            for (Media m : items) {
                JSONObject j = new JSONObject();
                j.put("s", m.src);
                j.put("v", m.video ? 1 : 0);
                j.put("o", m.source);
                if (!m.title.isEmpty()) j.put("t", m.title);
                if (!m.desc.isEmpty()) j.put("d", m.desc);
                if (!m.tags.isEmpty()) j.put("g", m.tags);
                j.put("a", m.added);
                if (m.fails > 0) j.put("f", m.fails);
                if (m.fav) j.put("fav", 1);
                a.put(j);
            }
            JSONArray d = new JSONArray();
            for (String s : deleted) d.put(s);
            JSONObject o = new JSONObject();
            o.put("items", a);
            o.put("del", d);
            writeAsync(bankFile, o.toString());
        } catch (Exception ignored) { }
    }

    private void saveDescs() {
        try {
            JSONArray a = new JSONArray();
            for (Map.Entry<String, Desc> e : descs.entrySet()) {
                JSONObject j = new JSONObject();
                j.put("s", e.getKey());
                j.put("t", e.getValue().text);
                j.put("ts", e.getValue().ts);
                j.put("ai", e.getValue().ai ? 1 : 0);
                a.put(j);
            }
            writeAsync(descFile, a.toString());
        } catch (Exception ignored) { }
    }

    private void writeAsync(final File f, final String content) {
        io.execute(new Runnable() {
            @Override public void run() {
                try {
                    File tmp = new File(f.getPath() + ".tmp");
                    try (FileOutputStream out = new FileOutputStream(tmp)) {
                        out.write(content.getBytes("UTF-8"));
                    }
                    if (!tmp.renameTo(f)) {
                        f.delete();
                        tmp.renameTo(f);
                    }
                } catch (Exception ignored) { }
            }
        });
    }

    private static String read(File f) throws Exception {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toString("UTF-8");
        }
    }
}
