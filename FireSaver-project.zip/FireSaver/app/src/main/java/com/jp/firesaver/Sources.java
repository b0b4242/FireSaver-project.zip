package com.jp.firesaver;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.regex.Pattern;

/** The online libraries. Each fetcher returns media with the info the source gives (title, description, keywords). */
final class Sources {
    private static final String PIXABAY_KEY = "58149898-5f722868931626f8394404c4f";
    private static final Random RND = new Random();

    // Filters: no text / people / graphics, only nature, places and space.
    private static final Pattern NASA_GOOD = Pattern.compile(
            "\\b(earth|planets?|mars|jupiter|saturn|venus|mercury|neptune|uranus|pluto|moon|lunar|sun|solar|"
            + "stars?|galax(y|ies)|nebula(e|s)?|aurora(s)?|cosmos|comets?|asteroids?|milky way|eclipse|hubble|webb|"
            + "clouds?|oceans?|hurricanes?|volcano(es)?|glaciers?|sunrises?|sunsets?|time-?lapse|landscapes?|aerial|"
            + "storms?|lightning|deserts?|mountains?|forests?|rivers?|coasts?|islands?|supernova|black holes?|"
            + "exoplanets?|constellations?|universe|orbit)\\b", Pattern.CASE_INSENSITIVE);

    private static final Pattern NASA_BAD = Pattern.compile(
            "\\b(astronauts?|cosmonauts?|crew|interviews?|briefings?|press|conference|talks?|lecture|ceremony|awards?|"
            + "tours?|welcome|students?|teachers?|kids|children|famil(y|ies)|launch(es|ed)?|rockets?|shuttle|"
            + "mission control|news|town hall|webinar|panel|remarks|q&a|live|says|said|discuss(es|ed)?|explains?|"
            + "administrator|director|scientists?|engineers?|dr|mr|ms|president|senator|congress|visits?|"
            + "celebrat\\w*|training|tests?|testing|simulat\\w*|lab|laboratory|facility|building|team|employees?|"
            + "people|woman|women|man|men|boys?|girls?|spacewalks?|suits?|portrait|hosts?|podcast|event|"
            + "salute|honou?r\\w*|tribute|memorial|anniversary|history|selfie|"
            + "visuali[sz]ations?|animat\\w*|graphics?|infographics?|trailer|promo\\w*|maps?|charts?|captions?|"
            + "subtitles?|titles?|credits?|narrat\\w*|voice-?over)\\b", Pattern.CASE_INSENSITIVE);

    private static final Pattern APOD_BAD = Pattern.compile(
            "\\b(annotated|annotations?|labell?ed|labels?|diagrams?|charts?|maps?|infographics?|illustrations?|"
            + "graphs?|posters?|comparisons?|collages?|montages?|captions?|text|logo|signs?|selfie|portrait|"
            + "people|astronauts?|artist'?s? (concept|illustration|impression|rendering))\\b", Pattern.CASE_INSENSITIVE);

    private static final Pattern PIX_BAD = Pattern.compile(
            "\\b(text|posters?|banners?|logos?|quotes?|typography|signs?|letters?|words?|cards?|advertis\\w*|"
            + "templates?|invitations?|watermark|labels?|titles?|fonts?|writing|slogan|message|inscription|"
            + "graffiti|billboard|subtitles?|captions?|intro|opener|countdown|"
            + "people|persons?|man|men|woman|women|girls?|boys?|portrait|couple|crowd|family|child|children|model|selfie)\\b", Pattern.CASE_INSENSITIVE);

    private static final Pattern COMMONS_BAD = Pattern.compile(
            "\\b(maps?|diagrams?|charts?|graphs?|posters?|logos?|signs?|signage|banners?|texts?|inscriptions?|"
            + "plaques?|information boards?|menus?|portraits?|people|persons?|man|men|woman|women|crowds?|"
            + "children|child|boys?|girls?|famil(y|ies)|groups?|tourists?|visitors?|spectators?|audience|"
            + "demonstrations?|protests?|parades?|festivals?|ceremon(y|ies)|weddings?|soldiers?|police|athletes?|"
            + "players?|teams?|selfies?|self-portraits?|fashion|models?|dancers?|musicians?|concerts?|paintings?|"
            + "drawings?|illustrations?|engravings?|lithographs?|postcards?|stamps?|manuscripts?|scans?|"
            + "advertisements?|books?|pages?|documents?|newspapers?|screenshots?|renderings?|traffic|markets?|"
            + "shops?|restaurants?)\\b", Pattern.CASE_INSENSITIVE);


    // ---------- helpers ----------

    static String clean(String s) {
        if (s == null) return "";
        return s.replaceAll("<[^>]*>", " ")
                .replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">")
                .replaceAll("\\s+", " ").trim();
    }

    /** Cuts at a sentence end when possible. */
    static String cap(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        String cut = s.substring(0, max);
        int dot = Math.max(cut.lastIndexOf(". "), Math.max(cut.lastIndexOf("! "), cut.lastIndexOf("? ")));
        if (dot > max / 2) return cut.substring(0, dot + 1);
        int sp = cut.lastIndexOf(' ');
        return (sp > 0 ? cut.substring(0, sp) : cut) + "…";
    }

    private static String str(Object o) {
        if (o == null || o == JSONObject.NULL) return "";
        if (o instanceof JSONArray) {
            JSONArray a = (JSONArray) o;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < a.length(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(a.optString(i));
            }
            return sb.toString();
        }
        return o.toString();
    }

    private static String https(String u) {
        return u.startsWith("http://") ? "https://" + u.substring(7) : u;
    }

    private static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    private static String firstTag(String tags) {
        if (tags == null || tags.isEmpty()) return "";
        String t = tags.split(",")[0].trim();
        return t.isEmpty() ? "" : Character.toUpperCase(t.charAt(0)) + t.substring(1);
    }

    // ---------- Bing ----------

    /** Bing image of the day, 2 random countries (about 16 photos). */
    static List<Media> bing() {
        List<String> markets = new ArrayList<>(Arrays.asList("en-US", "fr-FR", "ja-JP", "de-DE", "en-GB", "pt-BR"));
        Collections.shuffle(markets);
        List<Media> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (String mkt : markets.subList(0, 2)) {
            try {
                String json = Http.getString("https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=" + mkt);
                JSONArray arr = new JSONObject(json).getJSONArray("images");
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String url = "https://www.bing.com" + o.getString("urlbase") + "_1920x1080.jpg";
                    if (!seen.add(url)) continue;
                    Media m = new Media(url, false, "Bing");
                    m.title = clean(o.optString("title", ""));
                    m.desc = clean(o.optString("copyright", "").replaceAll("\\s*\\(©[^)]*\\)\\s*$", ""));
                    out.add(m);
                }
            } catch (Exception ignored) { }
        }
        return out;
    }

    // ---------- Pixabay ----------

    /** Pixabay: photos (editor's choice) and up to 12 videos of 8 to 90 s, from random themes. */
    static List<Media> pixabay() {
        List<Media> out = new ArrayList<>();
        List<String> themes = new ArrayList<>(Arrays.asList(
                "landscape", "mountains", "ocean", "aerial view", "forest", "sunset",
                "waterfall", "northern lights", "city night", "clouds", "beach", "lake",
                "cityscape", "skyline", "old town", "bridge", "castle", "lighthouse", "village", "harbor"));
        Collections.shuffle(themes);

        for (String q : themes.subList(0, 2)) {
            try {
                String json = Http.getString("https://pixabay.com/api/?key=" + PIXABAY_KEY + "&q=" + enc(q)
                        + "&image_type=photo&orientation=horizontal&min_width=1920&safesearch=true"
                        + "&editors_choice=true&per_page=20");
                JSONArray hits = new JSONObject(json).getJSONArray("hits");
                for (int i = 0; i < hits.length(); i++) {
                    JSONObject h = hits.getJSONObject(i);
                    String tags = h.optString("tags", "");
                    if (PIX_BAD.matcher(tags).find()) continue;
                    String u = h.optString("largeImageURL", "");
                    if (u.isEmpty()) continue;
                    Media m = new Media(https(u), false, "Pixabay");
                    m.tags = tags;
                    m.title = firstTag(tags);
                    out.add(m);
                }
            } catch (Exception ignored) { }
        }

        List<Media> vids = new ArrayList<>();
        for (String q : themes.subList(2, 4)) {
            try {
                String json = Http.getString("https://pixabay.com/api/videos/?key=" + PIXABAY_KEY + "&q=" + enc(q)
                        + "&video_type=film&min_width=1920&safesearch=true&per_page=20");
                JSONArray hits = new JSONObject(json).getJSONArray("hits");
                for (int i = 0; i < hits.length(); i++) {
                    JSONObject h = hits.getJSONObject(i);
                    int dur = h.optInt("duration", 0);
                    if (dur < 8 || dur > 90) continue;
                    String tags = h.optString("tags", "");
                    if (PIX_BAD.matcher(tags).find()) continue;
                    JSONObject v = h.getJSONObject("videos");
                    String u = v.getJSONObject("medium").optString("url", "");
                    if (u.isEmpty()) u = v.getJSONObject("large").optString("url", "");
                    if (u.isEmpty()) u = v.getJSONObject("small").optString("url", "");
                    if (u.isEmpty()) continue;
                    Media m = new Media(https(u), true, "Pixabay");
                    m.tags = tags;
                    m.title = firstTag(tags);
                    vids.add(m);
                }
            } catch (Exception ignored) { }
        }
        Collections.shuffle(vids);
        out.addAll(vids.subList(0, Math.min(12, vids.size())));
        return out;
    }

    // ---------- NASA ----------

    /** NASA Astronomy Picture of the Day: 24 random pictures, without photographer copyright, not annotated. */
    static List<Media> apod() {
        List<Media> out = new ArrayList<>();
        try {
            String json = Http.getString("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&count=24");
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (!"image".equals(o.optString("media_type"))) continue;
                if (o.has("copyright")) continue;
                String title = o.optString("title", "");
                String expl = o.optString("explanation", "");
                if (APOD_BAD.matcher(title + " " + expl).find()) continue;
                String u = o.optString("hdurl", "");
                if (u.isEmpty()) u = o.optString("url", "");
                if (u.isEmpty()) continue;
                Media m = new Media(https(u), false, "NASA");
                m.title = clean(title);
                m.desc = cap(clean(expl), 520);
                out.add(m);
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** NASA Image and Video Library: up to 6 videos about space / planets / stars / nature, no people or events. */
    static List<Media> nasaVideos() {
        List<Media> out = new ArrayList<>();
        try {
            List<String> queries = new ArrayList<>(Arrays.asList(
                    "earth from space", "aurora", "earth timelapse", "nebula", "galaxy", "jupiter",
                    "saturn", "mars", "moon surface", "sun solar", "milky way", "hubble", "stars universe",
                    "earth night"));
            Collections.shuffle(queries);
            LinkedHashMap<String, String[]> meta = new LinkedHashMap<>();   // id -> {title, description}
            for (String q : queries.subList(0, 5)) {
                try {
                    String json = Http.getString("https://images-api.nasa.gov/search?media_type=video&page_size=40&q=" + enc(q));
                    JSONArray arr = new JSONObject(json).getJSONObject("collection").getJSONArray("items");
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject d = arr.getJSONObject(i).getJSONArray("data").getJSONObject(0);
                        StringBuilder sb = new StringBuilder();
                        sb.append(d.optString("title", "")).append(' ').append(d.optString("description", ""));
                        JSONArray kw = d.optJSONArray("keywords");
                        if (kw != null) for (int j = 0; j < kw.length(); j++) sb.append(' ').append(kw.optString(j));
                        String text = sb.toString();
                        if (NASA_GOOD.matcher(text).find() && !NASA_BAD.matcher(text).find()) {
                            meta.put(d.getString("nasa_id"), new String[]{d.optString("title", ""), d.optString("description", "")});
                        }
                    }
                } catch (Exception ignored) { }
            }
            List<String> ids = new ArrayList<>(meta.keySet());
            Collections.shuffle(ids);
            for (String id : ids) {
                if (out.size() >= 6) break;
                try {
                    String json = Http.getString("https://images-api.nasa.gov/asset/" + enc(id).replace("+", "%20"));
                    JSONArray arr = new JSONObject(json).getJSONObject("collection").getJSONArray("items");
                    String large = null, medium = null;
                    for (int i = 0; i < arr.length(); i++) {
                        String h = arr.getJSONObject(i).getString("href");
                        String lh = h.toLowerCase();
                        if (lh.endsWith("~large.mp4")) large = h;
                        else if (lh.endsWith("~medium.mp4")) medium = h;
                    }
                    String pick = large != null ? large : medium;
                    if (pick == null) continue;
                    Media m = new Media(https(pick).replace(" ", "%20"), true, "NASA");
                    m.title = clean(meta.get(id)[0]);
                    m.desc = cap(clean(meta.get(id)[1]), 420);
                    out.add(m);
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return out;
    }

    // ---------- Wikimedia Commons ----------

    /** Large "Quality images" JPEGs of nature, cities and places. */
    static List<Media> commons() {
        List<Media> out = new ArrayList<>();
        List<String> themes = new ArrayList<>(Arrays.asList(
                "landscape", "mountain", "lake", "waterfall", "forest", "coast", "sunset", "glacier", "desert",
                "canyon", "island", "aerial view", "cityscape", "skyline", "old town", "bridge", "castle",
                "harbour", "lighthouse", "village", "temple", "national park"));
        Collections.shuffle(themes);
        String[] scopes = {" incategory:\"Quality images\"", " incategory:\"Featured pictures on Wikimedia Commons\"", ""};
        for (String theme : themes.subList(0, 4)) {
            List<Media> got = commonsSearch(theme + scopes[0], RND.nextInt(120));
            if (got.isEmpty()) got = commonsSearch(theme + scopes[0], 0);
            if (got.isEmpty()) got = commonsSearch(theme + scopes[1], 0);
            if (got.isEmpty()) got = commonsSearch(theme + scopes[2], 0);
            out.addAll(got);
        }
        return out;
    }

    private static List<Media> commonsSearch(String query, int offset) {
        List<Media> out = new ArrayList<>();
        try {
            String url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2"
                    + "&generator=search&gsrnamespace=6&gsrlimit=30&gsroffset=" + offset
                    + "&gsrsearch=" + enc(query + " filetype:bitmap")
                    + "&prop=imageinfo&iiprop=url%7Csize%7Cmime%7Cextmetadata&iiurlwidth=1920"
                    + "&iiextmetadatafilter=LicenseShortName%7CImageDescription%7CCategories%7CObjectName";
            JSONObject q0 = new JSONObject(Http.getString(url)).optJSONObject("query");
            if (q0 == null) return out;
            JSONArray pages = q0.optJSONArray("pages");
            if (pages == null) return out;
            for (int i = 0; i < pages.length() && out.size() < 8; i++) {
                JSONObject pg = pages.getJSONObject(i);
                JSONArray ii = pg.optJSONArray("imageinfo");
                if (ii == null || ii.length() == 0) continue;
                JSONObject info = ii.getJSONObject(0);
                if (!"image/jpeg".equals(info.optString("mime"))) continue;
                int w = info.optInt("width"), h = info.optInt("height");
                if (w < 1920 || h < 1080) continue;
                double ratio = (double) w / h;
                if (ratio < 1.3 || ratio > 2.5) continue;
                String thumb = info.optString("thumburl", "");
                if (thumb.isEmpty()) continue;
                JSONObject md = info.optJSONObject("extmetadata");
                if (md == null || md.optJSONObject("LicenseShortName") == null) continue;

                String objName = "", descr = "", cats = "";
                JSONObject o = md.optJSONObject("ObjectName");
                if (o != null) objName = clean(o.optString("value", ""));
                o = md.optJSONObject("ImageDescription");
                if (o != null) descr = clean(o.optString("value", ""));
                o = md.optJSONObject("Categories");
                if (o != null) cats = clean(o.optString("value", "")).replace("|", ", ");

                String pageTitle = pg.optString("title", "").replaceFirst("^File:", "")
                        .replaceFirst("\\.[A-Za-z0-9]+$", "").replace('_', ' ');
                String text = pageTitle + " " + objName + " " + descr + " " + cats.replace(", ", " | ");
                if (COMMONS_BAD.matcher(text).find()) continue;

                Media m = new Media(https(thumb), false, "Wikimedia Commons");
                m.title = !objName.isEmpty() ? objName : pageTitle;
                m.desc = cap(descr, 420);
                m.tags = cap(cats, 200);
                out.add(m);
            }
        } catch (Exception ignored) { }
        return out;
    }

    // ---------- Internet Archive ----------

    /** Photo items marked CC0 / Public Domain, tagged with a nature or place subject. */
    static List<Media> archive() {
        List<Media> out = new ArrayList<>();
        try {
            List<String> subjects = new ArrayList<>(Arrays.asList(
                    "landscape", "mountains", "lake", "waterfall", "forest", "coast", "sunset", "glacier",
                    "desert", "canyon", "island", "skyline", "cityscape", "bridge", "castle", "lighthouse"));
            Collections.shuffle(subjects);
            String lic = "(licenseurl:\"http://creativecommons.org/publicdomain/zero/1.0/\""
                    + " OR licenseurl:\"https://creativecommons.org/publicdomain/zero/1.0/\""
                    + " OR licenseurl:\"http://creativecommons.org/publicdomain/mark/1.0/\""
                    + " OR licenseurl:\"https://creativecommons.org/publicdomain/mark/1.0/\")";
            LinkedHashMap<String, String[]> meta = new LinkedHashMap<>();   // id -> {title, description, subjects}
            for (String subject : subjects.subList(0, 3)) {
                String q = "subject:(\"" + subject + "\") AND mediatype:image AND " + lic;
                int page = 1 + RND.nextInt(3);
                for (int attempt = 0; attempt < 2; attempt++) {
                    JSONArray docs = archiveSearch(q, page);
                    if (docs != null && docs.length() > 0) {
                        for (int i = 0; i < docs.length(); i++) {
                            JSONObject d = docs.getJSONObject(i);
                            String title = clean(str(d.opt("title")));
                            String desc = clean(str(d.opt("description")));
                            String subj = clean(str(d.opt("subject")));
                            if (COMMONS_BAD.matcher(title + " " + subj + " " + desc).find()) continue;
                            String id = d.optString("identifier", "");
                            if (!id.isEmpty()) meta.put(id, new String[]{title, desc, subj});
                        }
                        break;
                    }
                    page = 1;
                }
            }
            List<String> ids = new ArrayList<>(meta.keySet());
            Collections.shuffle(ids);
            for (String id : ids) {
                if (out.size() >= 10) break;
                try {
                    String json = Http.getString("https://archive.org/metadata/" + enc(id).replace("+", "%20"));
                    JSONArray files = new JSONObject(json).optJSONArray("files");
                    if (files == null) continue;
                    for (int i = 0; i < files.length(); i++) {
                        JSONObject f = files.getJSONObject(i);
                        if (!"JPEG".equals(f.optString("format"))) continue;
                        if (!"original".equals(f.optString("source"))) continue;
                        int w = parseIntSafe(f.optString("width"));
                        int h = parseIntSafe(f.optString("height"));
                        long size = parseIntSafe(f.optString("size"));
                        if (w < 1920 || h < 1080 || size > 15L * 1024 * 1024) continue;
                        double ratio = (double) w / h;
                        if (ratio < 1.3 || ratio > 2.5) continue;
                        String name = f.optString("name", "");
                        if (name.isEmpty()) continue;
                        String url = "https://archive.org/download/" + enc(id).replace("+", "%20")
                                + "/" + enc(name).replace("+", "%20").replace("%2F", "/");
                        Media m = new Media(url, false, "Internet Archive");
                        String[] mt = meta.get(id);
                        m.title = cap(mt[0], 120);
                        m.desc = cap(mt[1], 420);
                        m.tags = cap(mt[2], 200);
                        out.add(m);
                        break;
                    }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static JSONArray archiveSearch(String q, int page) {
        try {
            String url = "https://archive.org/advancedsearch.php?q=" + enc(q)
                    + "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=subject&fl%5B%5D=description"
                    + "&rows=30&page=" + page + "&output=json";
            return new JSONObject(Http.getString(url)).getJSONObject("response").getJSONArray("docs");
        } catch (Exception e) {
            return null;
        }
    }

    private static int parseIntSafe(String v) {
        try { return Integer.parseInt(v.trim()); } catch (Exception e) { return 0; }
    }
}
