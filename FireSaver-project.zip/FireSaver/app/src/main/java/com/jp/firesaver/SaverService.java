package com.jp.firesaver;

import android.service.dreams.DreamService;

/** Optional: lets FireSaver also be used as the system screensaver (needs one ADB command). */
public class SaverService extends DreamService {
    private SaverView view;

    @Override public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setInteractive(false);
        setFullscreen(true);
        view = new SaverView(this);
        setContentView(view);
    }

    @Override public void onDreamingStarted() {
        super.onDreamingStarted();
        view.start();
    }

    @Override public void onDreamingStopped() {
        view.stop();
        super.onDreamingStopped();
    }
}
