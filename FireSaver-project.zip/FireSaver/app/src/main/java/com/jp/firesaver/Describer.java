package com.jp.firesaver;

import android.graphics.Bitmap;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

/**
 * Builds the text of the description card.
 * 1) the source's own description, if it is detailed enough
 * 2) otherwise a vision AI (Gemini) when a key is configured, using the source info as context
 * 3) otherwise the information we have (keywords)
 */
final class Describer {
    static final class Result {
        final String text;
        final boolean ai;
        final boolean cacheable;
        Result(String text, boolean ai, boolean cacheable) { this.text = text; this.ai = ai; this.cacheable = cacheable; }
    }

    static boolean aiAvailable() { return !SecretKeys.GEMINI.isEmpty(); }

    /** Background thread only. frame may be null. */
    static Result build(Media m, Bitmap frame) {
        String original = Sources.clean(m.desc);
        if (isPrecise(original)) return new Result(Sources.cap(original, 460), false, true);

        boolean tryAi = aiAvailable() && frame != null;
        if (tryAi) {
            String t = gemini(m, original, frame);
            if (t != null && !t.isEmpty()) return new Result(t, true, true);
        }
        // not cached if the AI was available but failed: we will try again next time
        return new Result(fallback(m, original), false, !tryAi);
    }

    private static boolean isPrecise(String s) {
        if (s.length() < 90) return false;
        String[] words = s.split("\\s+");
        return words.length >= 14;
    }

    private static String fallback(Media m, String original) {
        StringBuilder sb = new StringBuilder();
        if (!original.isEmpty()) sb.append(Sources.cap(original, 400));
        if (!m.tags.isEmpty()) {
            if (sb.length() > 0) sb.append("\n");
            sb.append("Mots-clés : ").append(Sources.cap(m.tags, 160));
        }
        if (sb.length() == 0) sb.append("Aucune description disponible pour ce média.");
        return sb.toString();
    }

    private static String gemini(Media m, String original, Bitmap frame) {
        try {
            Bitmap small = frame;
            int w = frame.getWidth(), h = frame.getHeight();
            if (w > 768) small = Bitmap.createScaledBitmap(frame, 768, Math.max(1, Math.round(h * 768f / w)), true);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            small.compress(Bitmap.CompressFormat.JPEG, 80, bos);
            String b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);

            StringBuilder ctx = new StringBuilder();
            if (!m.title.isEmpty()) ctx.append("Titre : ").append(m.title).append(". ");
            if (!original.isEmpty()) ctx.append("Description de la source : ").append(Sources.cap(original, 300)).append(" ");
            if (!m.tags.isEmpty()) ctx.append("Mots-clés : ").append(Sources.cap(m.tags, 160)).append(". ");

            String prompt = "Décris cette " + (m.video ? "image extraite d'une vidéo" : "photo")
                    + " en français, en 2 à 4 phrases courtes, pour une fiche d'information élégante. "
                    + "Parle des éléments visibles, du paysage ou du lieu, de l'ambiance et de détails intéressants. "
                    + "N'affirme jamais ce dont tu n'es pas certain : utilise « semble », « probablement » ou « évoque ». "
                    + "N'invente aucun nom de lieu précis s'il n'est pas confirmé par le contexte fourni. "
                    + "Pas de titre, pas de liste, pas de markdown, ne parle pas de toi. "
                    + (ctx.length() > 0 ? "Contexte fourni par la source (peut être incomplet) : " + ctx : "");

            JSONObject textPart = new JSONObject().put("text", prompt);
            JSONObject imgPart = new JSONObject().put("inline_data",
                    new JSONObject().put("mime_type", "image/jpeg").put("data", b64));
            JSONObject body = new JSONObject()
                    .put("contents", new JSONArray().put(new JSONObject()
                            .put("parts", new JSONArray().put(textPart).put(imgPart))))
                    .put("generationConfig", new JSONObject()
                            .put("temperature", 0.4)
                            .put("maxOutputTokens", 500)
                            .put("thinkingConfig", new JSONObject().put("thinkingBudget", 0)));

            String resp = Http.postJson(
                    "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
                    body.toString(), SecretKeys.GEMINI);
            String text = new JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
            text = text.replaceAll("[*#_`]", "").trim();
            return text.isEmpty() ? null : Sources.cap(text, 520);
        } catch (Exception e) {
            return null;
        }
    }
}
