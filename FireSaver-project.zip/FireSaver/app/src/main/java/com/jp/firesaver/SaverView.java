package com.jp.firesaver;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * The screensaver itself (used by MainActivity and by the optional system dream SaverService).
 *
 * Sources:
 *  - If you put videos in /sdcard/Android/data/com.jp.firesaver/files/ (or links in urls.txt): only those, shuffled.
 *  - Otherwise an online mix, shuffled:
 *      * Bing "image of the day" photos
 *      * Pixabay photos and videos (free API key)
 */
public class SaverView extends FrameLayout {
    private static final int PHOTO_SECONDS = 15;
    private static final int MAX_VIDEO_SECONDS = 30; // every video is cut after this many seconds
    private static final String PIXABAY_KEY = "58149898-5f722868931626f8394404c4f";

    private static class Item {
        final String src;
        final boolean video;
        final boolean remote;
        Item(String src, boolean video, boolean remote) { this.src = src; this.video = video; this.remote = remote; }
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final VideoView video;
    private final FrameLayout photoLayer;
    private final ImageView[] imgs = new ImageView[2];
    private int cur = 0;
    private TextView msgView;

    private final List<Item> items = new ArrayList<>();
    private int index = -1;
    private int failures = 0;
    private volatile boolean running = false;
    private volatile int token = 0;

    private final Runnable nextRunnable = new Runnable() {
        @Override public void run() { next(); }
    };

    public SaverView(Context ctx) {
        super(ctx);
        setBackgroundColor(Color.BLACK);

        video = new VideoView(ctx);
        addView(video, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER));

        photoLayer = new FrameLayout(ctx);
        for (int i = 0; i < 2; i++) {
            ImageView iv = new ImageView(ctx);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setAlpha(0f);
            photoLayer.addView(iv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            imgs[i] = iv;
        }
        addView(photoLayer, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        photoLayer.setVisibility(View.GONE);

        TextClock clock = new TextClock(ctx);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("h:mm");
        clock.setTextColor(Color.argb(200, 255, 255, 255));
        clock.setTextSize(36);
        clock.setShadowLayer(8f, 0f, 2f, Color.BLACK);
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        lp.setMargins(80, 0, 0, 60);
        addView(clock, lp);

        video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer mp) { mp.setVolume(0f, 0f); failures = 0; }
        });
        video.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override public void onCompletion(MediaPlayer mp) { next(); }
        });
        video.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override public boolean onError(MediaPlayer mp, int what, int extra) {
                if (running) { failures++; next(); }
                return true;
            }
        });
    }

    // ---------- Lifecycle ----------

    public void start() {
        ui.removeCallbacksAndMessages(null);
        token++;
        running = true;
        items.clear();
        loadLocalVideos();
        if (items.isEmpty()) {
            loadOnlineAsync(token);
        } else {
            begin();
        }
    }

    public void stop() {
        running = false;
        token++;
        ui.removeCallbacksAndMessages(null);
        video.stopPlayback();
    }

    private void begin() {
        clearMessage();
        Collections.shuffle(items);
        index = -1;
        failures = 0;
        next();
    }

    private void next() {
        ui.removeCallbacks(nextRunnable);
        if (!running || items.isEmpty()) return;
        if (failures > items.size()) {
            showMessage("Impossible de lire les photos/videos.");
            return;
        }
        index++;
        if (index >= items.size()) {
            index = 0;
            Collections.shuffle(items);
        }
        Item it = items.get(index);
        if (it.video) playVideo(it); else showPhoto(it);
    }

    // ---------- Local videos (optional) ----------

    private File appDir() {
        File d = getContext().getExternalFilesDir(null);
        return d != null ? d : getContext().getFilesDir();
    }

    private void loadLocalVideos() {
        File[] files = appDir().listFiles();
        if (files != null) {
            for (File f : files) {
                String n = f.getName().toLowerCase();
                if (n.endsWith(".mp4") || n.endsWith(".mov") || n.endsWith(".mkv") || n.endsWith(".webm"))
                    items.add(new Item(f.getAbsolutePath(), true, false));
            }
        }
        File urls = new File(appDir(), "urls.txt");
        if (urls.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(urls))) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.startsWith("http")) items.add(new Item(line, true, true));
                }
            } catch (Exception ignored) { }
        }
    }

    // ---------- Playback ----------

    private void playVideo(Item it) {
        photoLayer.setVisibility(View.GONE);
        video.setVisibility(View.VISIBLE);
        video.setVideoURI(it.remote ? Uri.parse(it.src) : Uri.fromFile(new File(it.src)));
        video.start();
        ui.postDelayed(nextRunnable, MAX_VIDEO_SECONDS * 1000L);
    }

    private void showPhoto(final Item it) {
        video.stopPlayback();
        video.setVisibility(View.GONE);
        photoLayer.setVisibility(View.VISIBLE);
        final int t = token;
        new Thread(new Runnable() {
            @Override public void run() {
                final Bitmap b = decodeBytes(httpGetBytes(it.src, 30 * 1024 * 1024));
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (!running || t != token) return;
                        if (b == null) {
                            failures++;
                            ui.postDelayed(nextRunnable, 500);
                            return;
                        }
                        failures = 0;
                        showBitmap(b);
                        ui.postDelayed(nextRunnable, PHOTO_SECONDS * 1000L);
                    }
                });
            }
        }).start();
    }

    private void showBitmap(Bitmap b) {
        ImageView next = imgs[1 - cur];
        ImageView prev = imgs[cur];
        next.setScaleType(b.getWidth() >= b.getHeight()
                ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
        next.setImageBitmap(b);
        next.setAlpha(0f);
        next.setScaleX(1f);
        next.setScaleY(1f);
        next.bringToFront();
        next.animate().alpha(1f).setDuration(1500).start();
        long zoomMs = (PHOTO_SECONDS + 3) * 1000L;
        ObjectAnimator sx = ObjectAnimator.ofFloat(next, "scaleX", 1f, 1.1f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(next, "scaleY", 1f, 1.1f);
        sx.setDuration(zoomMs); sy.setDuration(zoomMs);
        sx.setInterpolator(new LinearInterpolator());
        sy.setInterpolator(new LinearInterpolator());
        sx.start(); sy.start();
        prev.animate().alpha(0f).setDuration(1500).start();
        cur = 1 - cur;
    }

    // ---------- Messages ----------

    private void showMessage(String msg) {
        if (msgView == null) {
            msgView = new TextView(getContext());
            msgView.setTextColor(Color.WHITE);
            msgView.setTextSize(22);
            msgView.setGravity(Gravity.CENTER);
            addView(msgView, new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        }
        msgView.setText(msg);
        msgView.setVisibility(View.VISIBLE);
    }

    private void clearMessage() {
        if (msgView != null) msgView.setVisibility(View.GONE);
    }

    // ---------- Online libraries ----------

    private void loadOnlineAsync(final int t) {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    List<Item> found = new ArrayList<>();
                    while (running && t == token && found.isEmpty()) {
                        found.addAll(fetchBing());
                        found.addAll(fetchPixabay());
                        if (found.isEmpty()) {
                            ui.post(new Runnable() {
                                @Override public void run() {
                                    if (t == token) showMessage("Pas de connexion Internet.\nNouvel essai dans quelques secondes...");
                                }
                            });
                            Thread.sleep(15000);
                        }
                    }
                    final List<Item> result = found;
                    ui.post(new Runnable() {
                        @Override public void run() {
                            if (!running || t != token || result.isEmpty()) return;
                            items.addAll(result);
                            begin();
                        }
                    });
                } catch (InterruptedException ignored) { }
            }
        }).start();
    }

    /** Bing image of the day, 2 random countries (about 16 photos). */
    private List<Item> fetchBing() {
        List<String> markets = new ArrayList<>(Arrays.asList("en-US", "fr-FR", "ja-JP", "de-DE", "en-GB", "pt-BR"));
        Collections.shuffle(markets);
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (String m : markets.subList(0, 2)) {
            try {
                String json = httpGetString("https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=" + m);
                JSONArray arr = new JSONObject(json).getJSONArray("images");
                for (int i = 0; i < arr.length(); i++) {
                    String base = arr.getJSONObject(i).getString("urlbase");
                    set.add("https://www.bing.com" + base + "_1920x1080.jpg");
                }
            } catch (Exception ignored) { }
        }
        List<Item> out = new ArrayList<>();
        for (String u : set) out.add(new Item(u, false, true));
        return out;
    }

    /** Pixabay: ~24 landscape photos and up to 12 videos (8 to 90 s long), from 2 random themes each. */
    private List<Item> fetchPixabay() {
        List<Item> out = new ArrayList<>();
        List<String> themes = new ArrayList<>(Arrays.asList(
                "landscape", "mountains", "ocean", "aerial view", "forest", "sunset",
                "waterfall", "northern lights", "city night", "clouds", "beach", "lake"));
        Collections.shuffle(themes);

        // Photos
        for (String q : themes.subList(0, 2)) {
            try {
                String json = httpGetString("https://pixabay.com/api/?key=" + PIXABAY_KEY
                        + "&q=" + URLEncoder.encode(q, "UTF-8")
                        + "&image_type=photo&orientation=horizontal&min_width=1920&safesearch=true&per_page=12");
                JSONArray hits = new JSONObject(json).getJSONArray("hits");
                for (int i = 0; i < hits.length(); i++) {
                    String u = hits.getJSONObject(i).optString("largeImageURL", "");
                    if (!u.isEmpty()) out.add(new Item(https(u), false, true));
                }
            } catch (Exception ignored) { }
        }

        // Videos
        List<Item> vids = new ArrayList<>();
        for (String q : themes.subList(2, 4)) {
            try {
                String json = httpGetString("https://pixabay.com/api/videos/?key=" + PIXABAY_KEY
                        + "&q=" + URLEncoder.encode(q, "UTF-8")
                        + "&video_type=film&min_width=1920&safesearch=true&per_page=20");
                JSONArray hits = new JSONObject(json).getJSONArray("hits");
                for (int i = 0; i < hits.length(); i++) {
                    JSONObject h = hits.getJSONObject(i);
                    int dur = h.optInt("duration", 0);
                    if (dur < 8 || dur > 90) continue;
                    JSONObject v = h.getJSONObject("videos");
                    String u = v.getJSONObject("medium").optString("url", "");
                    if (u.isEmpty()) u = v.getJSONObject("large").optString("url", "");
                    if (u.isEmpty()) u = v.getJSONObject("small").optString("url", "");
                    if (!u.isEmpty()) vids.add(new Item(https(u), true, true));
                }
            } catch (Exception ignored) { }
        }
        Collections.shuffle(vids);
        out.addAll(vids.subList(0, Math.min(12, vids.size())));
        return out;
    }

    private static String https(String u) {
        return u.startsWith("http://") ? "https://" + u.substring(7) : u;
    }

    // ---------- HTTP helpers ----------

    private String httpGetString(String url) throws Exception {
        byte[] b = httpGetBytes(url, 5 * 1024 * 1024);
        if (b == null) throw new Exception("empty");
        return new String(b, "UTF-8");
    }

    private byte[] httpGetBytes(String url, int maxBytes) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(20000);
            c.setRequestProperty("User-Agent", "FireSaver/1.0");
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) {
                    bos.write(buf, 0, n);
                    if (bos.size() > maxBytes) return null;
                }
                return bos.toByteArray();
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private Bitmap decodeBytes(byte[] d) {
        if (d == null) return null;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(d, 0, d.length, o);
            int s = 1;
            while (o.outWidth / s > 2400) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeByteArray(d, 0, d.length, o2);
        } catch (Throwable e) {
            return null;
        }
    }
}
