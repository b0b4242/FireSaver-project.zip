package com.jp.firesaver;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

/**
 * The screensaver itself (used by MainActivity and by the optional system dream SaverService).
 *
 * Sources:
 *  - If you put videos in /sdcard/Android/data/com.jp.firesaver/files/ (or links in urls.txt): only those, shuffled.
 *  - Otherwise an online mix, shuffled:
 *      * Bing "image of the day" photos
 *      * Pixabay photos and videos (free API key)
 *      * Wikimedia Commons "Quality images" photos of nature, cities and places
 *      * Internet Archive photos (only items marked public domain / CC0)
 *      * NASA "Astronomy Picture of the Day" photos + NASA Image and Video Library videos
 *
 * Transitions: photo -> photo = crossfade + slow zoom. Anything involving a video = fade through black,
 * and the fade only lifts once the new video really shows its first frame.
 */
public class SaverView extends FrameLayout {
    private static final int PHOTO_SECONDS = 15;
    private static final int MAX_VIDEO_SECONDS = 30; // every video is cut after this many seconds
    private static final long FADE_OUT_MS = 600;
    private static final long FADE_IN_MS = 900;
    private static final String PIXABAY_KEY = "58149898-5f722868931626f8394404c4f";

    // NASA video filter: must talk about space/nature, must NOT talk about people/events.
    private static final Pattern NASA_GOOD = Pattern.compile(
            "\\b(earth|planets?|mars|jupiter|saturn|venus|mercury|neptune|uranus|pluto|moon|lunar|sun|solar|"
            + "stars?|galax(y|ies)|nebula(e|s)?|aurora(s)?|cosmos|comets?|asteroids?|milky way|eclipse|hubble|webb|"
            + "clouds?|oceans?|hurricanes?|volcano(es)?|glaciers?|sunrises?|sunsets?|time-?lapse|landscapes?|aerial|"
            + "storms?|lightning|deserts?|mountains?|forests?|rivers?|coasts?|islands?|supernova|black holes?|"
            + "exoplanets?|constellations?|universe|orbit)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern NASA_BAD = Pattern.compile(
            "\\b(astronauts?|cosmonauts?|crew|interviews?|briefings?|press|conference|talks?|lecture|ceremony|awards?|"
            + "tours?|welcome|students?|teachers?|kids|children|famil(y|ies)|launch(es|ed)?|rockets?|shuttle|"
            + "mission control|news|town hall|webinar|panel|remarks|q&a|live|says|said|discuss(es|ed)?|explains?|"
            + "administrator|director|scientists?|engineers?|dr|mr|ms|president|senator|congress|visits?|"
            + "celebrat\\w*|training|tests?|testing|simulat\\w*|lab|laboratory|facility|building|team|employees?|"
            + "people|woman|women|man|men|boys?|girls?|spacewalks?|suits?|portrait|hosts?|podcast|event|"
            + "salute|honou?r\\w*|tribute|memorial|anniversary|history|selfie|"
            + "visuali[sz]ations?|animat\\w*|graphics?|infographics?|trailer|promo\\w*|maps?|charts?|captions?|"
            + "subtitles?|titles?|credits?|narrat\\w*|voice-?over)\\b", Pattern.CASE_INSENSITIVE);

    // Photos: drop annotated / labelled / diagram-like pictures (they contain text).
    private static final Pattern APOD_BAD = Pattern.compile(
            "\\b(annotated|annotations?|labell?ed|labels?|diagrams?|charts?|maps?|infographics?|illustrations?|"
            + "graphs?|posters?|comparisons?|collages?|montages?|captions?|text|logo|signs?|selfie|portrait|"
            + "people|astronauts?|artist'?s? (concept|illustration|impression|rendering))\\b", Pattern.CASE_INSENSITIVE);
    // Pixabay tags that usually mean "there is writing on it".
    private static final Pattern PIX_BAD = Pattern.compile(
            "\\b(text|posters?|banners?|logos?|quotes?|typography|signs?|letters?|words?|cards?|advertis\\w*|"
            + "templates?|invitations?|watermark|labels?|titles?|fonts?|writing|slogan|message|inscription|"
            + "graffiti|billboard|subtitles?|captions?|intro|opener|countdown|"
            + "people|persons?|man|men|woman|women|girls?|boys?|portrait|couple|crowd|family|child|children|model|selfie)\\b", Pattern.CASE_INSENSITIVE);

    // Wikimedia Commons: drop anything whose title/description/categories mention people, writing or non-photos.
    private static final Pattern COMMONS_BAD = Pattern.compile(
            "\\b(maps?|diagrams?|charts?|graphs?|posters?|logos?|signs?|signage|banners?|texts?|inscriptions?|"
            + "plaques?|information boards?|menus?|portraits?|people|persons?|man|men|woman|women|crowds?|"
            + "children|child|boys?|girls?|famil(y|ies)|groups?|tourists?|visitors?|spectators?|audience|"
            + "demonstrations?|protests?|parades?|festivals?|ceremon(y|ies)|weddings?|soldiers?|police|athletes?|"
            + "players?|teams?|selfies?|self-portraits?|fashion|models?|dancers?|musicians?|concerts?|paintings?|"
            + "drawings?|illustrations?|engravings?|lithographs?|postcards?|stamps?|manuscripts?|scans?|"
            + "advertisements?|books?|pages?|documents?|newspapers?|screenshots?|renderings?|traffic|markets?|"
            + "shops?|restaurants?)\\b", Pattern.CASE_INSENSITIVE);

    private static class Item {
        final String src;
        final boolean video;
        final boolean remote;
        Item(String src, boolean video, boolean remote) { this.src = src; this.video = video; this.remote = remote; }
    }

    private interface Source { List<Item> get(); }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final VideoView video;
    private final FrameLayout photoLayer;
    private final View fader;
    private final TextView sourceView;
    private final ImageView[] imgs = new ImageView[2];
    private int cur = 0;

    private final List<Item> items = new ArrayList<>();
    private int index = -1;
    private int failures = 0;
    private boolean shownOnce = false;
    private boolean currentIsVideo = false;
    private Runnable pending;
    private volatile boolean running = false;
    private volatile int token = 0;

    // next photo downloaded in advance
    private volatile Bitmap preBmp;
    private volatile int preIndex = -1;

    private final Runnable nextRunnable = new Runnable() {
        @Override public void run() { next(); }
    };
    private final Runnable liftRunnable = new Runnable() {
        @Override public void run() { liftFader(); }
    };
    private final Runnable renderStartRunnable = new Runnable() {
        @Override public void run() {
            if (!running) return;
            liftFader();
            ui.removeCallbacks(nextRunnable);
            ui.postDelayed(nextRunnable, MAX_VIDEO_SECONDS * 1000L);
        }
    };

    public SaverView(Context ctx) {
        super(ctx);
        setBackgroundColor(Color.BLACK);

        video = new VideoView(ctx);
        addView(video, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER));

        photoLayer = new FrameLayout(ctx);
        for (int i = 0; i < 2; i++) {
            ImageView iv = new ImageView(ctx);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setAlpha(0f);
            photoLayer.addView(iv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            imgs[i] = iv;
        }
        addView(photoLayer, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        photoLayer.setVisibility(View.GONE);

        fader = new View(ctx);
        fader.setBackgroundColor(Color.BLACK);
        fader.setAlpha(0f);
        addView(fader, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        TextClock clock = new TextClock(ctx);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("h:mm");
        clock.setTextColor(Color.argb(200, 255, 255, 255));
        clock.setTextSize(36);
        clock.setShadowLayer(8f, 0f, 2f, Color.BLACK);
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        lp.setMargins(80, 0, 0, 60);
        addView(clock, lp);

        // Very discreet source label (bottom-right): only visible if you look for it.
        sourceView = new TextView(ctx);
        sourceView.setTextColor(Color.argb(70, 255, 255, 255));
        sourceView.setTextSize(10);
        sourceView.setShadowLayer(3f, 0f, 1f, Color.argb(90, 0, 0, 0));
        LayoutParams slp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        slp.setMargins(0, 0, 36, 22);
        addView(sourceView, slp);

        video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer mp) {
                mp.setVolume(0f, 0f);
                failures = 0;
                if (Build.VERSION.SDK_INT < 26) ui.postDelayed(renderStartRunnable, 400);
            }
        });
        if (Build.VERSION.SDK_INT >= 26) {
            video.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                @Override public boolean onInfo(MediaPlayer mp, int what, int extra) {
                    if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) renderStartRunnable.run();
                    return false;
                }
            });
        }
        video.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override public void onCompletion(MediaPlayer mp) { next(); }
        });
        video.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override public boolean onError(MediaPlayer mp, int what, int extra) {
                if (running) { failures++; next(); }
                return true;
            }
        });
    }

    // ---------- Lifecycle ----------

    public void start() {
        ui.removeCallbacksAndMessages(null);
        token++;
        running = true;
        items.clear();
        shownOnce = false;
        currentIsVideo = false;
        pending = null;
        preBmp = null;
        preIndex = -1;
        fader.setAlpha(0f);
        sourceView.setText("");
        loadLocalVideos();
        if (items.isEmpty()) {
            loadOnlineAsync(token);
        } else {
            begin();
        }
    }

    public void stop() {
        running = false;
        token++;
        ui.removeCallbacksAndMessages(null);
        video.stopPlayback();
    }

    private void begin() {
        Collections.shuffle(items);
        index = -1;
        failures = 0;
        next();
    }

    private void next() {
        ui.removeCallbacks(nextRunnable);
        if (pending != null) { ui.removeCallbacks(pending); pending = null; }
        if (!running || items.isEmpty()) return;
        if (failures > items.size()) {
            showMessage("Impossible de lire les photos/videos.");
            return;
        }
        index++;
        if (index >= items.size()) {
            index = 0;
            Collections.shuffle(items);
            preBmp = null;
            preIndex = -1;
        }
        final Item it = items.get(index);
        boolean fade = shownOnce && (it.video || currentIsVideo);
        if (fade) {
            fader.animate().alpha(1f).setDuration(FADE_OUT_MS).start();
            pending = new Runnable() {
                @Override public void run() { pending = null; show(it); }
            };
            ui.postDelayed(pending, FADE_OUT_MS);
        } else {
            show(it);
        }
    }

    private void show(Item it) {
        shownOnce = true;
        currentIsVideo = it.video;
        if (it.video) playVideo(it); else showPhoto(it);
    }

    private void liftFader() {
        fader.animate().alpha(0f).setDuration(FADE_IN_MS).start();
    }

    // ---------- Local videos (optional) ----------

    private File appDir() {
        File d = getContext().getExternalFilesDir(null);
        return d != null ? d : getContext().getFilesDir();
    }

    private void loadLocalVideos() {
        File[] files = appDir().listFiles();
        if (files != null) {
            for (File f : files) {
                String n = f.getName().toLowerCase();
                if (n.endsWith(".mp4") || n.endsWith(".mov") || n.endsWith(".mkv") || n.endsWith(".webm"))
                    items.add(new Item(f.getAbsolutePath(), true, false));
            }
        }
        File urls = new File(appDir(), "urls.txt");
        if (urls.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(urls))) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.startsWith("http")) items.add(new Item(line, true, true));
                }
            } catch (Exception ignored) { }
        }
    }

    // ---------- Playback ----------

    private void playVideo(Item it) {
        imgs[0].animate().cancel();
        imgs[1].animate().cancel();
        imgs[0].setAlpha(0f);
        imgs[1].setAlpha(0f);
        photoLayer.setVisibility(View.GONE);
        video.setVisibility(View.VISIBLE);
        video.setVideoURI(it.remote ? Uri.parse(it.src) : Uri.fromFile(new File(it.src)));
        video.start();
        setSourceLabel(it);
        // safety nets: never stay black, never get stuck on a video that does not start
        ui.postDelayed(liftRunnable, 6000);
        ui.postDelayed(nextRunnable, (MAX_VIDEO_SECONDS + 15) * 1000L);
    }

    private void showPhoto(final Item it) {
        video.stopPlayback();
        video.setVisibility(View.GONE);
        photoLayer.setVisibility(View.VISIBLE);
        final int t = token;
        final int myIndex = index;
        if (preIndex == myIndex && preBmp != null) {
            Bitmap b = preBmp;
            preBmp = null;
            preIndex = -1;
            onPhotoReady(b, t, it);
            return;
        }
        new Thread(new Runnable() {
            @Override public void run() {
                final Bitmap b = decodeBytes(httpGetBytes(it.src, 30 * 1024 * 1024));
                ui.post(new Runnable() {
                    @Override public void run() { onPhotoReady(b, t, it); }
                });
            }
        }).start();
    }

    private void onPhotoReady(Bitmap b, int t, Item it) {
        if (!running || t != token) return;
        if (b == null) {
            failures++;
            ui.postDelayed(nextRunnable, 500);
            return;
        }
        failures = 0;
        showBitmap(b);
        setSourceLabel(it);
        liftFader();
        ui.postDelayed(nextRunnable, PHOTO_SECONDS * 1000L);
        prefetchNext();
    }

    private void prefetchNext() {
        final int ni = index + 1;
        if (ni >= items.size()) return;
        final Item it = items.get(ni);
        if (it.video) return;
        final int t = token;
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap b = decodeBytes(httpGetBytes(it.src, 30 * 1024 * 1024));
                if (b != null && t == token) {
                    preBmp = b;
                    preIndex = ni;
                }
            }
        }).start();
    }

    private void showBitmap(Bitmap b) {
        ImageView next = imgs[1 - cur];
        ImageView prev = imgs[cur];
        next.setScaleType(b.getWidth() >= b.getHeight()
                ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
        next.setImageBitmap(b);
        next.setAlpha(0f);
        next.setScaleX(1f);
        next.setScaleY(1f);
        next.bringToFront();
        next.animate().alpha(1f).setDuration(1500).start();
        long zoomMs = (PHOTO_SECONDS + 3) * 1000L;
        ObjectAnimator sx = ObjectAnimator.ofFloat(next, "scaleX", 1f, 1.1f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(next, "scaleY", 1f, 1.1f);
        sx.setDuration(zoomMs); sy.setDuration(zoomMs);
        sx.setInterpolator(new LinearInterpolator());
        sy.setInterpolator(new LinearInterpolator());
        sx.start(); sy.start();
        prev.animate().alpha(0f).setDuration(1500).start();
        cur = 1 - cur;
    }

    // ---------- Source label ----------

    private void setSourceLabel(Item it) {
        sourceView.setText(sourceLabel(it));
    }

    private String sourceLabel(Item it) {
        if (!it.remote) return "";
        String host = Uri.parse(it.src).getHost();
        if (host == null) return "";
        host = host.toLowerCase();
        if (host.contains("bing.com")) return "Bing";
        if (host.contains("pixabay.com")) return "Pixabay";
        if (host.contains("nasa.gov")) return "NASA";
        if (host.contains("wikimedia.org") || host.contains("wikipedia.org")) return "Wikimedia Commons";
        if (host.contains("archive.org")) return "Internet Archive";
        return host.startsWith("www.") ? host.substring(4) : host;
    }

    // ---------- Messages ----------

    /** No text is ever drawn on screen: on a problem the screen just stays clean (black) and retries. */
    private void showMessage(String msg) {
        liftFader();
    }

    // ---------- Online libraries ----------

    /** Each library loads in its own thread; playback starts as soon as the first one answers. */
    private void loadOnlineAsync(final int t) {
        final AtomicInteger left = new AtomicInteger(6);
        launch(t, left, new Source() { @Override public List<Item> get() { return fetchBing(); } });
        launch(t, left, new Source() { @Override public List<Item> get() { return fetchPixabay(); } });
        launch(t, left, new Source() { @Override public List<Item> get() { return fetchApod(); } });
        launch(t, left, new Source() { @Override public List<Item> get() { return fetchNasaVideos(); } });
        launch(t, left, new Source() { @Override public List<Item> get() { return fetchCommons(); } });
        launch(t, left, new Source() { @Override public List<Item> get() { return fetchArchive(); } });
    }

    private void launch(final int t, final AtomicInteger left, final Source src) {
        new Thread(new Runnable() {
            @Override public void run() {
                List<Item> r;
                try { r = src.get(); } catch (Throwable e) { r = new ArrayList<>(); }
                final List<Item> res = r;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (!running || t != token) return;
                        if (!res.isEmpty()) addOnline(res);
                        if (left.decrementAndGet() == 0 && items.isEmpty()) {
                            showMessage("Pas de connexion Internet.\nNouvel essai dans quelques secondes...");
                            ui.postDelayed(new Runnable() {
                                @Override public void run() { if (running && t == token) loadOnlineAsync(t); }
                            }, 15000);
                        }
                    }
                });
            }
        }).start();
    }

    private void addOnline(List<Item> r) {
        if (items.isEmpty()) {
            items.addAll(r);
            begin();
            return;
        }
        for (Item i : r) {
            int lo = Math.min(index + 1, items.size());
            int pos = lo + rnd.nextInt(items.size() - lo + 1);
            items.add(pos, i);
        }
    }

    /** Bing image of the day, 2 random countries (about 16 photos). */
    private List<Item> fetchBing() {
        List<String> markets = new ArrayList<>(Arrays.asList("en-US", "fr-FR", "ja-JP", "de-DE", "en-GB", "pt-BR"));
        Collections.shuffle(markets);
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (String m : markets.subList(0, 2)) {
            try {
                String json = httpGetString("https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=" + m);
                JSONArray arr = new JSONObject(json).getJSONArray("images");
                for (int i = 0; i < arr.length(); i++) {
                    String base = arr.getJSONObject(i).getString("urlbase");
                    set.add("https://www.bing.com" + base + "_1920x1080.jpg");
                }
            } catch (Exception ignored) { }
        }
        List<Item> out = new ArrayList<>();
        for (String u : set) out.add(new Item(u, false, true));
        return out;
    }

    /** Pixabay: ~24 landscape photos and up to 12 videos (8 to 90 s long), from random themes. */
    private List<Item> fetchPixabay() {
        List<Item> out = new ArrayList<>();
        List<String> themes = new ArrayList<>(Arrays.asList(
                "landscape", "mountains", "ocean", "aerial view", "forest", "sunset",
                "waterfall", "northern lights", "city night", "clouds", "beach", "lake",
                "cityscape", "skyline", "old town", "bridge", "castle", "lighthouse", "village", "harbor"));
        Collections.shuffle(themes);

        for (String q : themes.subList(0, 2)) {
            try {
                String json = httpGetString("https://pixabay.com/api/?key=" + PIXABAY_KEY
                        + "&q=" + URLEncoder.encode(q, "UTF-8")
                        + "&image_type=photo&orientation=horizontal&min_width=1920&safesearch=true&editors_choice=true&per_page=20");
                JSONArray hits = new JSONObject(json).getJSONArray("hits");
                for (int i = 0; i < hits.length(); i++) {
                    JSONObject h = hits.getJSONObject(i);
                    if (PIX_BAD.matcher(h.optString("tags", "")).find()) continue;
                    String u = h.optString("largeImageURL", "");
                    if (!u.isEmpty()) out.add(new Item(https(u), false, true));
                }
            } catch (Exception ignored) { }
        }

        List<Item> vids = new ArrayList<>();
        for (String q : themes.subList(2, 4)) {
            try {
                String json = httpGetString("https://pixabay.com/api/videos/?key=" + PIXABAY_KEY
                        + "&q=" + URLEncoder.encode(q, "UTF-8")
                        + "&video_type=film&min_width=1920&safesearch=true&per_page=20");
                JSONArray hits = new JSONObject(json).getJSONArray("hits");
                for (int i = 0; i < hits.length(); i++) {
                    JSONObject h = hits.getJSONObject(i);
                    int dur = h.optInt("duration", 0);
                    if (dur < 8 || dur > 90) continue;
                    if (PIX_BAD.matcher(h.optString("tags", "")).find()) continue;
                    JSONObject v = h.getJSONObject("videos");
                    String u = v.getJSONObject("medium").optString("url", "");
                    if (u.isEmpty()) u = v.getJSONObject("large").optString("url", "");
                    if (u.isEmpty()) u = v.getJSONObject("small").optString("url", "");
                    if (!u.isEmpty()) vids.add(new Item(https(u), true, true));
                }
            } catch (Exception ignored) { }
        }
        Collections.shuffle(vids);
        out.addAll(vids.subList(0, Math.min(12, vids.size())));
        return out;
    }

    /** NASA Astronomy Picture of the Day: 24 random pictures, keeping only images without a photographer copyright. */
    private List<Item> fetchApod() {
        List<Item> out = new ArrayList<>();
        try {
            String json = httpGetString("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&count=24");
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                if (!"image".equals(o.optString("media_type"))) continue;
                if (o.has("copyright")) continue;
                if (APOD_BAD.matcher(o.optString("title", "") + " " + o.optString("explanation", "")).find()) continue;
                String u = o.optString("hdurl", "");
                if (u.isEmpty()) u = o.optString("url", "");
                if (u.isEmpty()) continue;
                out.add(new Item(https(u), false, true));
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** NASA Image and Video Library: up to 6 videos about space / planets / stars / nature, no people or events. */
    private List<Item> fetchNasaVideos() {
        List<Item> out = new ArrayList<>();
        try {
            List<String> queries = new ArrayList<>(Arrays.asList(
                    "earth from space", "aurora", "earth timelapse", "nebula", "galaxy", "jupiter",
                    "saturn", "mars", "moon surface", "sun solar", "milky way", "hubble", "stars universe",
                    "earth night"));
            Collections.shuffle(queries);
            LinkedHashSet<String> idSet = new LinkedHashSet<>();
            for (String q : queries.subList(0, 5)) {
                try {
                    String json = httpGetString("https://images-api.nasa.gov/search?media_type=video&page_size=40&q="
                            + URLEncoder.encode(q, "UTF-8"));
                    JSONArray arr = new JSONObject(json).getJSONObject("collection").getJSONArray("items");
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject d = arr.getJSONObject(i).getJSONArray("data").getJSONObject(0);
                        StringBuilder sb = new StringBuilder();
                        sb.append(d.optString("title", "")).append(' ').append(d.optString("description", ""));
                        JSONArray kw = d.optJSONArray("keywords");
                        if (kw != null) for (int j = 0; j < kw.length(); j++) sb.append(' ').append(kw.optString(j));
                        String text = sb.toString();
                        if (NASA_GOOD.matcher(text).find() && !NASA_BAD.matcher(text).find())
                            idSet.add(d.getString("nasa_id"));
                    }
                } catch (Exception ignored) { }
            }
            List<String> ids = new ArrayList<>(idSet);
            Collections.shuffle(ids);
            for (String id : ids) {
                if (out.size() >= 6) break;
                try {
                    String json = httpGetString("https://images-api.nasa.gov/asset/"
                            + URLEncoder.encode(id, "UTF-8").replace("+", "%20"));
                    JSONArray arr = new JSONObject(json).getJSONObject("collection").getJSONArray("items");
                    String large = null, medium = null;
                    for (int i = 0; i < arr.length(); i++) {
                        String h = arr.getJSONObject(i).getString("href");
                        String lh = h.toLowerCase();
                        if (lh.endsWith("~large.mp4")) large = h;
                        else if (lh.endsWith("~medium.mp4")) medium = h;
                    }
                    String pick = large != null ? large : medium;
                    if (pick != null) out.add(new Item(https(pick).replace(" ", "%20"), true, true));
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** Wikimedia Commons: large "Quality images" JPEGs of nature, cities and places. */
    private List<Item> fetchCommons() {
        List<Item> out = new ArrayList<>();
        List<String> themes = new ArrayList<>(Arrays.asList(
                "landscape", "mountain", "lake", "waterfall", "forest", "coast", "sunset", "glacier", "desert",
                "canyon", "island", "aerial view", "cityscape", "skyline", "old town", "bridge", "castle",
                "harbour", "lighthouse", "village", "temple", "national park"));
        Collections.shuffle(themes);
        String[] scopes = {" incategory:\"Quality images\"", " incategory:\"Featured pictures on Wikimedia Commons\"", ""};
        for (String theme : themes.subList(0, 4)) {
            List<Item> got = commonsSearch(theme + scopes[0], rnd.nextInt(120));
            if (got.isEmpty()) got = commonsSearch(theme + scopes[0], 0);
            if (got.isEmpty()) got = commonsSearch(theme + scopes[1], 0);
            if (got.isEmpty()) got = commonsSearch(theme + scopes[2], 0);
            out.addAll(got);
        }
        return out;
    }

    private List<Item> commonsSearch(String query, int offset) {
        List<Item> out = new ArrayList<>();
        try {
            String url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&formatversion=2"
                    + "&generator=search&gsrnamespace=6&gsrlimit=30&gsroffset=" + offset
                    + "&gsrsearch=" + URLEncoder.encode(query + " filetype:bitmap", "UTF-8")
                    + "&prop=imageinfo&iiprop=url%7Csize%7Cmime%7Cextmetadata&iiurlwidth=1920"
                    + "&iiextmetadatafilter=LicenseShortName%7CImageDescription%7CCategories%7CObjectName";
            JSONObject query0 = new JSONObject(httpGetString(url)).optJSONObject("query");
            if (query0 == null) return out;
            JSONArray pages = query0.optJSONArray("pages");
            if (pages == null) return out;
            for (int i = 0; i < pages.length() && out.size() < 8; i++) {
                JSONObject pg = pages.getJSONObject(i);
                JSONArray ii = pg.optJSONArray("imageinfo");
                if (ii == null || ii.length() == 0) continue;
                JSONObject info = ii.getJSONObject(0);
                if (!"image/jpeg".equals(info.optString("mime"))) continue;
                int w = info.optInt("width"), h = info.optInt("height");
                if (w < 1920 || h < 1080) continue;
                double ratio = (double) w / h;
                if (ratio < 1.3 || ratio > 2.5) continue;
                String thumb = info.optString("thumburl", "");
                if (thumb.isEmpty()) continue;
                JSONObject md = info.optJSONObject("extmetadata");
                if (md == null || md.optJSONObject("LicenseShortName") == null) continue;
                StringBuilder sb = new StringBuilder(pg.optString("title", ""));
                for (String k : new String[]{"ObjectName", "ImageDescription", "Categories"}) {
                    JSONObject o = md.optJSONObject(k);
                    if (o != null) sb.append(' ').append(o.optString("value", ""));
                }
                String text = sb.toString().replaceAll("<[^>]*>", " ").replace('_', ' ');
                if (COMMONS_BAD.matcher(text).find()) continue;
                out.add(new Item(https(thumb), false, true));
            }
        } catch (Exception ignored) { }
        return out;
    }

    /**
     * Internet Archive: photo items whose license is CC0 / Public Domain Mark, tagged with a nature or place subject.
     * Step 1 = search, step 2 = look up the original JPEG of each item (size and shape checked).
     */
    private List<Item> fetchArchive() {
        List<Item> out = new ArrayList<>();
        try {
            List<String> subjects = new ArrayList<>(Arrays.asList(
                    "landscape", "mountains", "lake", "waterfall", "forest", "coast", "sunset", "glacier",
                    "desert", "canyon", "island", "skyline", "cityscape", "bridge", "castle", "lighthouse"));
            Collections.shuffle(subjects);
            String lic = "(licenseurl:\"http://creativecommons.org/publicdomain/zero/1.0/\""
                    + " OR licenseurl:\"https://creativecommons.org/publicdomain/zero/1.0/\""
                    + " OR licenseurl:\"http://creativecommons.org/publicdomain/mark/1.0/\""
                    + " OR licenseurl:\"https://creativecommons.org/publicdomain/mark/1.0/\")";
            LinkedHashSet<String> ids = new LinkedHashSet<>();
            for (String subject : subjects.subList(0, 3)) {
                String q = "subject:(\"" + subject + "\") AND mediatype:image AND " + lic;
                int page = 1 + rnd.nextInt(3);
                for (int attempt = 0; attempt < 2; attempt++) {
                    JSONArray docs = archiveSearch(q, page);
                    if (docs != null && docs.length() > 0) {
                        for (int i = 0; i < docs.length(); i++) {
                            JSONObject d = docs.getJSONObject(i);
                            String text = (d.optString("title", "") + " " + String.valueOf(d.opt("subject"))
                                    + " " + String.valueOf(d.opt("description"))).replaceAll("<[^>]*>", " ");
                            if (COMMONS_BAD.matcher(text).find()) continue;
                            String id = d.optString("identifier", "");
                            if (!id.isEmpty()) ids.add(id);
                        }
                        break;
                    }
                    page = 1; // random page was empty: retry on the first page
                }
            }
            List<String> idList = new ArrayList<>(ids);
            Collections.shuffle(idList);
            for (String id : idList) {
                if (out.size() >= 10) break;
                try {
                    String json = httpGetString("https://archive.org/metadata/"
                            + URLEncoder.encode(id, "UTF-8").replace("+", "%20"));
                    JSONArray files = new JSONObject(json).optJSONArray("files");
                    if (files == null) continue;
                    for (int i = 0; i < files.length(); i++) {
                        JSONObject f = files.getJSONObject(i);
                        if (!"JPEG".equals(f.optString("format"))) continue;
                        if (!"original".equals(f.optString("source"))) continue;
                        int w = parseIntSafe(f.optString("width"));
                        int h = parseIntSafe(f.optString("height"));
                        long size = parseIntSafe(f.optString("size"));
                        if (w < 1920 || h < 1080 || size > 15L * 1024 * 1024) continue;
                        double ratio = (double) w / h;
                        if (ratio < 1.3 || ratio > 2.5) continue;
                        String name = f.optString("name", "");
                        if (name.isEmpty()) continue;
                        out.add(new Item("https://archive.org/download/" + URLEncoder.encode(id, "UTF-8").replace("+", "%20")
                                + "/" + URLEncoder.encode(name, "UTF-8").replace("+", "%20").replace("%2F", "/"),
                                false, true));
                        break;
                    }
                } catch (Exception ignored) { }
            }
        } catch (Exception ignored) { }
        return out;
    }

    private JSONArray archiveSearch(String q, int page) {
        try {
            String url = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(q, "UTF-8")
                    + "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=subject&fl%5B%5D=description"
                    + "&rows=30&page=" + page + "&output=json";
            return new JSONObject(httpGetString(url)).getJSONObject("response").getJSONArray("docs");
        } catch (Exception e) {
            return null;
        }
    }

    private static int parseIntSafe(String v) {
        try { return Integer.parseInt(v.trim()); } catch (Exception e) { return 0; }
    }

    private static String https(String u) {
        return u.startsWith("http://") ? "https://" + u.substring(7) : u;
    }

    // ---------- HTTP helpers ----------

    private String httpGetString(String url) throws Exception {
        byte[] b = httpGetBytes(url, 5 * 1024 * 1024);
        if (b == null) throw new Exception("empty");
        return new String(b, "UTF-8");
    }

    private byte[] httpGetBytes(String url, int maxBytes) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(20000);
            c.setRequestProperty("User-Agent", "FireSaver/1.0 (personal screensaver; https://github.com/b0b4242/FireSaver-project.zip)");
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) {
                    bos.write(buf, 0, n);
                    if (bos.size() > maxBytes) return null;
                }
                return bos.toByteArray();
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private Bitmap decodeBytes(byte[] d) {
        if (d == null) return null;
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(d, 0, d.length, o);
            int s = 1;
            while (o.outWidth / s > 2400) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeByteArray(d, 0, d.length, o2);
        } catch (Throwable e) {
            return null;
        }
    }
}
