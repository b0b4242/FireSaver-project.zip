package com.jp.firesaver;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The ambient mode. Plays photos and videos from the media bank, with:
 *  - crossfade + soft blur transitions (never a black screen), photos preloaded 2 ahead
 *  - favourites shown more often, delete with confirmation, previous / next
 *  - an options menu (Back), a description card (Menu), a very discreet source label
 * Used by MainActivity (remote control) and by the optional system dream SaverService.
 */
public class SaverView extends FrameLayout {
    private static final int PHOTO_SECONDS = 15;
    private static final int MAX_VIDEO_SECONDS = 30;
    private static final long FADE_MS = 1400;

    private static final int MODE_PLAY = 0;
    private static final int MODE_MENU = 1;
    private static final int MODE_CONFIRM = 2;
    private static final int MODE_CARD = 3;

    // ---------- small helper classes ----------

    private static final class Frame {
        final Bitmap full;
        final Bitmap tiny;   // very small copy, scaled up = blur
        Frame(Bitmap full, Bitmap tiny) { this.full = full; this.tiny = tiny; }
    }

    /** One layer for photos: sharp image + a blurred copy on top that fades away. */
    private static final class Slot {
        final FrameLayout box;
        final ImageView sharp;
        final ImageView blur;
        int gen;
        ObjectAnimator zx, zy;

        Slot(Context c) {
            box = new FrameLayout(c);
            box.setBackgroundColor(Color.BLACK);
            sharp = new ImageView(c);
            blur = new ImageView(c);
            sharp.setScaleType(ImageView.ScaleType.CENTER_CROP);
            blur.setScaleType(ImageView.ScaleType.CENTER_CROP);
            box.addView(sharp, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            box.addView(blur, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            blur.setAlpha(0f);
            box.setAlpha(0f);
        }

        void set(Frame f, boolean cover) {
            ImageView.ScaleType t = cover ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER;
            sharp.setScaleType(t);
            blur.setScaleType(t);
            sharp.setImageBitmap(f.full);
            blur.setImageBitmap(f.tiny);
        }

        void stopZoom() {
            if (zx != null) zx.cancel();
            if (zy != null) zy.cancel();
            box.setScaleX(1f);
            box.setScaleY(1f);
        }

        void zoom(long ms) {
            stopZoom();
            zx = ObjectAnimator.ofFloat(box, "scaleX", 1f, 1.08f);
            zy = ObjectAnimator.ofFloat(box, "scaleY", 1f, 1.08f);
            zx.setDuration(ms);
            zy.setDuration(ms);
            zx.setInterpolator(new LinearInterpolator());
            zy.setInterpolator(new LinearInterpolator());
            zx.start();
            zy.start();
        }
    }

    /** Frosted-glass panel: draws a blurred copy of the picture behind it, then a dark tint. */
    private static final class Glass extends LinearLayout {
        private Bitmap backdrop;
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path clip = new Path();
        private final Rect dst = new Rect();
        private final float radius;

        Glass(Context c, float radiusPx) {
            super(c);
            radius = radiusPx;
            setOrientation(VERTICAL);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(2f);
            border.setColor(Color.argb(55, 255, 255, 255));
        }

        void setBackdrop(Bitmap b) {
            backdrop = b;
            invalidate();
        }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            clip.reset();
            clip.addRoundRect(new RectF(1, 1, w - 1, h - 1), radius, radius, Path.Direction.CW);
        }

        @Override protected void dispatchDraw(Canvas canvas) {
            canvas.save();
            canvas.clipPath(clip);
            View p = (View) getParent();
            if (backdrop != null && p != null) {
                canvas.save();
                canvas.translate(-getLeft(), -getTop());
                dst.set(0, 0, p.getWidth(), p.getHeight());
                canvas.drawBitmap(backdrop, null, dst, paint);
                canvas.restore();
            }
            canvas.drawColor(Color.argb(115, 18, 18, 22));
            canvas.restore();
            canvas.drawPath(clip, border);
            super.dispatchDraw(canvas);
        }
    }

    private interface Src { List<Media> get(); }

    // ---------- state ----------

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final Bank bank;
    private final LruCache<String, Frame> cache;

    private TextureView tv;
    private FrameLayout photoLayer;
    private final Slot[] slots = new Slot[2];
    private int cur = 0;
    private View scrim;
    private TextClock clock;
    private TextView sourceView;
    private TextView toast;
    private Glass menuPanel, confirmPanel, cardPanel;
    private TextView menuCount;
    private final TextView[] menuRows = new TextView[3];
    private final TextView[] confirmRows = new TextView[2];
    private TextView cardTitle, cardMeta, cardBody, cardFoot;

    private int mode = MODE_PLAY;
    private int menuIndex = 0;
    private int confirmIndex = 1;
    private int toastGen = 0;

    private volatile boolean running = false;
    private volatile int token = 0;
    private int reqId = 0;
    private int sourcesLeft = 0;
    private int failStreak = 0;

    private Media current;
    private Frame currentFrame;
    private boolean videoOnScreen = false;
    private boolean revealPending = false;

    private final List<Media> hist = new ArrayList<>();
    private int hpos = -1;
    private final List<Media> upcoming = new ArrayList<>();
    private final Set<String> loading = Collections.synchronizedSet(new HashSet<String>());
    private ExecutorService pool;

    // video player
    private Surface surface;
    private boolean surfaceReady = false;
    private MediaPlayer mp;
    private Media pendingVideo;
    private int pendingReq;
    private int vw, vh;

    private final Runnable advanceRunnable = new Runnable() {
        @Override public void run() { if (running && mode == MODE_PLAY) goNext(); }
    };

    // ---------- construction ----------

    public SaverView(Context ctx) {
        super(ctx);
        setBackgroundColor(Color.BLACK);
        bank = Bank.get(ctx);
        cache = new LruCache<String, Frame>(36 * 1024 * 1024) {
            @Override protected int sizeOf(String key, Frame f) {
                return f.full.getByteCount() + f.tiny.getByteCount();
            }
        };

        // video layer (bottom)
        tv = new TextureView(ctx);
        tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                surface = new Surface(st);
                surfaceReady = true;
                if (pendingVideo != null && pendingReq == reqId && pendingVideo == current) {
                    startPlayer(pendingVideo, pendingReq);
                }
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { applyTransform(); }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                surfaceReady = false;
                videoOnScreen = false;
                releasePlayer();
                if (surface != null) surface.release();
                surface = null;
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }
        });
        addView(tv, match());

        // photo layers
        photoLayer = new FrameLayout(ctx);
        for (int i = 0; i < 2; i++) {
            slots[i] = new Slot(ctx);
            photoLayer.addView(slots[i].box, match());
        }
        addView(photoLayer, match());

        // dark gradient behind panels
        scrim = new View(ctx);
        scrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00000000, 0xB0000000}));
        scrim.setAlpha(0f);
        scrim.setVisibility(GONE);
        addView(scrim, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(280), Gravity.BOTTOM));

        // clock (bottom-left)
        clock = new TextClock(ctx);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("h:mm");
        clock.setTextColor(Color.argb(200, 255, 255, 255));
        clock.setTextSize(36);
        clock.setShadowLayer(8f, 0f, 2f, Color.BLACK);
        LayoutParams clp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        clp.setMargins(80, 0, 0, 60);
        addView(clock, clp);

        // very discreet source label (bottom-right): 2 letters, almost transparent
        sourceView = new TextView(ctx);
        sourceView.setTextColor(Color.argb(34, 255, 255, 255));
        sourceView.setTextSize(10);
        sourceView.setShadowLayer(3f, 0f, 1f, Color.argb(60, 0, 0, 0));
        LayoutParams slp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        slp.setMargins(0, 0, 36, 22);
        addView(sourceView, slp);

        // brief confirmation pill (top-center)
        toast = text("", 14, Color.WHITE, "sans-serif-medium");
        GradientDrawable tbg = new GradientDrawable();
        tbg.setColor(Color.argb(150, 20, 20, 24));
        tbg.setCornerRadius(dp(22));
        toast.setBackground(tbg);
        toast.setPadding(dp(20), dp(9), dp(20), dp(9));
        toast.setAlpha(0f);
        LayoutParams tlp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        tlp.topMargin = dp(28);
        addView(toast, tlp);

        buildMenuPanel(ctx);
        buildConfirmPanel(ctx);
        buildCardPanel(ctx);
    }

    private void buildMenuPanel(Context ctx) {
        menuPanel = new Glass(ctx, dp(26));
        menuPanel.setPadding(dp(26), dp(22), dp(26), dp(16));
        menuPanel.addView(text("Options", 13, Color.argb(160, 255, 255, 255), "sans-serif-medium"));
        menuCount = text("", 11, Color.argb(115, 255, 255, 255), "sans-serif");
        menuCount.setPadding(0, dp(3), 0, dp(10));
        menuPanel.addView(menuCount);
        String[] labels = {"Mettre en favori", "Supprimer le média", "Retour à la lecture"};
        for (int i = 0; i < 3; i++) {
            menuRows[i] = row(labels[i]);
            menuPanel.addView(menuRows[i]);
        }
        LayoutParams lp = new LayoutParams(dp(340), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = dp(44);
        menuPanel.setAlpha(0f);
        menuPanel.setVisibility(GONE);
        addView(menuPanel, lp);
    }

    private void buildConfirmPanel(Context ctx) {
        confirmPanel = new Glass(ctx, dp(26));
        confirmPanel.setPadding(dp(26), dp(22), dp(26), dp(16));
        confirmPanel.addView(text("Supprimer ce média ?", 17, Color.WHITE, "sans-serif-medium"));
        TextView sub = text("Il sera retiré de la banque et ne reviendra plus.", 12, Color.argb(130, 255, 255, 255), "sans-serif");
        sub.setPadding(0, dp(4), 0, dp(12));
        confirmPanel.addView(sub);
        String[] labels = {"Oui, supprimer", "Annuler"};
        for (int i = 0; i < 2; i++) {
            confirmRows[i] = row(labels[i]);
            confirmPanel.addView(confirmRows[i]);
        }
        LayoutParams lp = new LayoutParams(dp(340), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = dp(44);
        confirmPanel.setAlpha(0f);
        confirmPanel.setVisibility(GONE);
        addView(confirmPanel, lp);
    }

    private void buildCardPanel(Context ctx) {
        cardPanel = new Glass(ctx, dp(28));
        cardPanel.setPadding(dp(34), dp(28), dp(34), dp(24));
        cardTitle = text("", 26, Color.WHITE, "sans-serif-medium");
        cardTitle.setMaxLines(2);
        cardTitle.setEllipsize(TextUtils.TruncateAt.END);
        cardMeta = text("", 13, Color.argb(150, 255, 255, 255), "sans-serif");
        cardMeta.setPadding(0, dp(4), 0, dp(14));
        cardBody = text("", 17, Color.argb(235, 255, 255, 255), "sans-serif-light");
        cardBody.setLineSpacing(dp(4), 1.0f);
        cardBody.setMaxLines(8);
        cardBody.setEllipsize(TextUtils.TruncateAt.END);
        cardFoot = text("", 12, Color.argb(120, 255, 255, 255), "sans-serif");
        cardFoot.setPadding(0, dp(16), 0, 0);
        cardPanel.addView(cardTitle);
        cardPanel.addView(cardMeta);
        cardPanel.addView(cardBody);
        cardPanel.addView(cardFoot);
        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        lp.setMargins(dp(48), 0, dp(48), dp(36));
        cardPanel.setAlpha(0f);
        cardPanel.setVisibility(GONE);
        addView(cardPanel, lp);
    }

    private LayoutParams match() {
        return new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, float sp, int color, String family) {
        TextView t = new TextView(getContext());
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create(family, Typeface.NORMAL));
        t.setLetterSpacing(0.01f);
        return t;
    }

    private TextView row(String label) {
        TextView t = text(label, 17, Color.argb(190, 255, 255, 255), "sans-serif-medium");
        t.setPadding(dp(16), dp(11), dp(16), dp(11));
        return t;
    }

    private void styleRows(TextView[] rows, int sel) {
        for (int i = 0; i < rows.length; i++) {
            TextView t = rows[i];
            if (i == sel) {
                GradientDrawable g = new GradientDrawable();
                g.setColor(Color.argb(70, 255, 255, 255));
                g.setCornerRadius(dp(12));
                t.setBackground(g);
                t.setTextColor(Color.WHITE);
            } else {
                t.setBackground(null);
                t.setTextColor(Color.argb(190, 255, 255, 255));
            }
        }
    }

    private static void anim(View v, float alpha, long dur, long delay, TimeInterpolator ip) {
        v.animate().cancel();
        v.animate().alpha(alpha).setDuration(dur).setStartDelay(delay).setInterpolator(ip).start();
    }

    // ---------- lifecycle ----------

    public void start() {
        ui.removeCallbacksAndMessages(null);
        token++;
        running = true;
        reqId++;
        mode = MODE_PLAY;
        hidePanelsNow();
        pool = Executors.newFixedThreadPool(2);
        current = null;
        currentFrame = null;
        videoOnScreen = false;
        revealPending = false;
        pendingVideo = null;
        failStreak = 0;
        hist.clear();
        hpos = -1;
        upcoming.clear();
        sourceView.setText("");
        launchSources(token);
        if (bank.total() > 0) goNext();
    }

    public void stop() {
        running = false;
        token++;
        ui.removeCallbacksAndMessages(null);
        pendingVideo = null;
        releasePlayer();
        if (pool != null) {
            pool.shutdownNow();
            pool = null;
        }
        cache.evictAll();
        loading.clear();
    }

    // ---------- online libraries -> bank ----------

    private void launchSources(final int t) {
        sourcesLeft = 6;
        launch(t, new Src() { @Override public List<Media> get() { return Sources.bing(); } });
        launch(t, new Src() { @Override public List<Media> get() { return Sources.pixabay(); } });
        launch(t, new Src() { @Override public List<Media> get() { return Sources.apod(); } });
        launch(t, new Src() { @Override public List<Media> get() { return Sources.nasaVideos(); } });
        launch(t, new Src() { @Override public List<Media> get() { return Sources.commons(); } });
        launch(t, new Src() { @Override public List<Media> get() { return Sources.archive(); } });
    }

    private void launch(final int t, final Src s) {
        new Thread(new Runnable() {
            @Override public void run() {
                List<Media> r;
                try { r = s.get(); } catch (Throwable e) { r = new ArrayList<Media>(); }
                final List<Media> res = r;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (!running || t != token) return;
                        if (!res.isEmpty()) {
                            bank.addAll(res);
                            if (current == null) goNext();
                        }
                        sourcesLeft--;
                        if (sourcesLeft == 0 && bank.total() == 0) {
                            ui.postDelayed(new Runnable() {
                                @Override public void run() { if (running && t == token) launchSources(t); }
                            }, 15000);
                        }
                    }
                });
            }
        }).start();
    }

    // ---------- choosing what to show ----------

    private double weight(Media m) { return m.fav ? 3.0 : 1.0; }

    /** Random pick, favourites 3x more likely, avoiding the most recent ones. */
    private Media pickFromBank() {
        List<Media> all = bank.snapshot();
        if (all.isEmpty()) return null;
        Set<String> recent = new HashSet<>();
        int n = Math.min(14, all.size() / 3);
        for (int i = hist.size() - 1; i >= 0 && recent.size() < n; i--) recent.add(hist.get(i).src);
        for (Media u : upcoming) recent.add(u.src);
        List<Media> cands = new ArrayList<>();
        double total = 0;
        for (Media m : all) {
            if (recent.contains(m.src)) continue;
            cands.add(m);
            total += weight(m);
        }
        if (cands.isEmpty()) {
            cands = all;
            total = 0;
            for (Media m : cands) total += weight(m);
        }
        double r = rnd.nextDouble() * total;
        for (Media m : cands) {
            r -= weight(m);
            if (r <= 0) return m;
        }
        return cands.get(cands.size() - 1);
    }

    private Media takeNext() {
        while (!upcoming.isEmpty()) {
            Media m = upcoming.remove(0);
            if (bank.contains(m)) return m;
        }
        return pickFromBank();
    }

    private void fillUpcoming() {
        while (upcoming.size() < 2) {
            Media m = pickFromBank();
            if (m == null || upcoming.contains(m)) break;
            upcoming.add(m);
        }
        for (Media m : new ArrayList<>(upcoming)) if (!m.video) prefetch(m);
    }

    private void goNext() {
        Media m = null;
        while (hpos < hist.size() - 1) {
            Media h = hist.get(hpos + 1);
            if (bank.contains(h)) {
                hpos++;
                m = h;
                break;
            }
            hist.remove(hpos + 1);
        }
        if (m == null) {
            m = takeNext();
            if (m == null) return;
            hist.add(m);
            if (hist.size() > 60) hist.remove(0);
            hpos = hist.size() - 1;
        }
        showMedia(m);
    }

    private void goPrev() {
        while (hpos > 0) {
            Media h = hist.get(hpos - 1);
            if (bank.contains(h)) {
                hpos--;
                showMedia(h);
                return;
            }
            hist.remove(hpos - 1);
            hpos--;
        }
    }

    // ---------- showing a media ----------

    private void showMedia(final Media m) {
        final int id = ++reqId;
        cancelAdvance();
        current = m;
        if (m.video) {
            if (videoOnScreen) captureVideoToTopSlot();
            revealPending = true;
            pendingVideo = m;
            pendingReq = id;
            if (surfaceReady) startPlayer(m, id);
        } else {
            revealPending = false;
            Frame f = cache.get(m.src);
            if (f != null) {
                displayPhoto(m, f, id);
            } else if (pool != null) {
                final int t = token;
                try {
                    pool.execute(new Runnable() {
                        @Override public void run() {
                            final Frame fr = loadFrame(m);
                            ui.post(new Runnable() {
                                @Override public void run() {
                                    if (!running || t != token) return;
                                    if (fr == null) {
                                        if (id == reqId) handleLoadFailure();
                                        return;
                                    }
                                    cache.put(m.src, fr);
                                    if (id == reqId) displayPhoto(m, fr, id);
                                }
                            });
                        }
                    });
                } catch (Exception ignored) { }
            }
        }
        fillUpcoming();
    }

    private void handleLoadFailure() {
        failStreak++;
        final int id = reqId;
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                if (running && mode == MODE_PLAY && id == reqId) goNext();
            }
        }, failStreak > 3 ? 12000 : 400);
    }

    private void displayPhoto(Media m, Frame f, final int id) {
        if (id != reqId) return;
        failStreak = 0;
        if (videoOnScreen) captureVideoToTopSlot();
        crossfadeTo(f, f.full.getWidth() >= f.full.getHeight());
        currentFrame = f;
        setLabel(m);
        scheduleAdvance(PHOTO_SECONDS * 1000L);
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                if (id == reqId && current != null && !current.video) releasePlayer();
            }
        }, FADE_MS + 250);
    }

    /** The new picture fades in (blurred -> sharp) over the old one, which blurs slightly meanwhile. */
    private void crossfadeTo(Frame f, boolean cover) {
        final Slot in = slots[1 - cur];
        final Slot out = slots[cur];
        in.gen++;
        in.box.animate().cancel();
        in.blur.animate().cancel();
        in.set(f, cover);
        in.box.setAlpha(0f);
        in.blur.setAlpha(1f);
        in.box.bringToFront();
        anim(in.box, 1f, FADE_MS, 0, new DecelerateInterpolator());
        anim(in.blur, 0f, FADE_MS + 200, 150, null);
        anim(out.blur, 1f, FADE_MS, 0, null);
        in.zoom((PHOTO_SECONDS + 4) * 1000L);
        final int g = out.gen;
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                if (out.gen == g) {
                    out.box.animate().cancel();
                    out.box.setAlpha(0f);
                    out.blur.animate().cancel();
                    out.blur.setAlpha(0f);
                    out.stopZoom();
                }
            }
        }, FADE_MS + 100);
        cur = 1 - cur;
    }

    private void setLabel(Media m) {
        sourceView.setText(abbr(m.source));
    }

    /** First + last letter: Bing -> Bg, NASA -> Na. */
    private static String abbr(String s) {
        if (s == null) return "";
        String t = s.replace(" ", "");
        if (t.length() < 2) return t;
        return t.substring(0, 1).toUpperCase() + t.substring(t.length() - 1).toLowerCase();
    }

    // ---------- photo loading / preloading ----------

    private void prefetch(final Media m) {
        if (pool == null || cache.get(m.src) != null || !loading.add(m.src)) return;
        final int t = token;
        try {
            pool.execute(new Runnable() {
                @Override public void run() {
                    Frame f = loadFrame(m);
                    loading.remove(m.src);
                    if (f != null && t == token) cache.put(m.src, f);
                }
            });
        } catch (Exception e) {
            loading.remove(m.src);
        }
    }

    private Frame loadFrame(Media m) {
        Http.Result r = Http.get(m.src, 30 * 1024 * 1024);
        if (r.data == null) {
            if (r.code == 403 || r.code == 404 || r.code == 410) bank.recordFail(m);
            return null;
        }
        Bitmap b = decode(r.data);
        if (b == null) {
            bank.recordFail(m);
            return null;
        }
        bank.recordOk(m);
        return new Frame(b, tiny(b));
    }

    private static Bitmap decode(byte[] d) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(d, 0, d.length, o);
            int s = 1;
            while (o.outWidth / s > 2400) s *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = s;
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeByteArray(d, 0, d.length, o2);
        } catch (Throwable e) {
            return null;
        }
    }

    /** Very small copy of the picture: drawn full screen it looks blurred. */
    private static Bitmap tiny(Bitmap b) {
        Bitmap mid = Bitmap.createScaledBitmap(b, Math.max(32, b.getWidth() / 6), Math.max(18, b.getHeight() / 6), true);
        Bitmap t = Bitmap.createScaledBitmap(mid, Math.max(16, b.getWidth() / 24), Math.max(9, b.getHeight() / 24), true);
        if (mid != b && mid != t) mid.recycle();
        return t;
    }

    // ---------- video ----------

    private void startPlayer(final Media m, final int id) {
        releasePlayer();
        if (surface == null) return;
        final MediaPlayer p = new MediaPlayer();
        mp = p;
        try {
            p.setDataSource(m.src);
            p.setSurface(surface);
            p.setVolume(0f, 0f);
            p.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                @Override public void onVideoSizeChanged(MediaPlayer x, int w, int h) {
                    vw = w;
                    vh = h;
                    applyTransform();
                }
            });
            p.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override public void onPrepared(MediaPlayer x) {
                    if (p != mp || id != reqId) return;
                    vw = x.getVideoWidth();
                    vh = x.getVideoHeight();
                    applyTransform();
                    x.start();
                    bank.recordOk(m);
                    ui.postDelayed(new Runnable() {
                        @Override public void run() { if (p == mp) onVideoFrame(id); }
                    }, 2500);   // safety if the "first frame" event never comes
                }
            });
            p.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                @Override public boolean onInfo(MediaPlayer x, int what, int extra) {
                    if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START && p == mp) onVideoFrame(id);
                    return false;
                }
            });
            p.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(MediaPlayer x) {
                    if (p != mp || id != reqId) return;
                    if (mode == MODE_PLAY) {
                        goNext();
                    } else {
                        try { x.seekTo(0); x.start(); } catch (Exception ignored) { }
                    }
                }
            });
            p.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override public boolean onError(MediaPlayer x, int what, int extra) {
                    if (p == mp && id == reqId) {
                        if (isOnline()) bank.recordFail(m);
                        handleLoadFailure();
                    }
                    return true;
                }
            });
            p.prepareAsync();
        } catch (Exception e) {
            handleLoadFailure();
        }
    }

    /** First video frame is on screen: the old picture dissolves (blurring) to reveal it. */
    private void onVideoFrame(int id) {
        if (!revealPending || id != reqId) return;
        revealPending = false;
        failStreak = 0;
        videoOnScreen = true;
        currentFrame = null;
        Slot top = slots[cur];
        anim(top.blur, 1f, FADE_MS, 0, null);
        anim(top.box, 0f, FADE_MS, 120, new DecelerateInterpolator());
        setLabel(current);
        scheduleAdvance(MAX_VIDEO_SECONDS * 1000L);
    }

    /** Puts the current video frame into a photo layer so it can be dissolved like a photo. */
    private void captureVideoToTopSlot() {
        Frame snap = snapshotVideo();
        if (snap != null) {
            Slot top = slots[cur];
            top.gen++;
            top.box.animate().cancel();
            top.blur.animate().cancel();
            top.stopZoom();
            top.set(snap, true);
            top.blur.setAlpha(0f);
            top.box.setAlpha(1f);
            top.box.bringToFront();
            currentFrame = snap;
        }
        videoOnScreen = false;
    }

    private Frame snapshotVideo() {
        try {
            if (!surfaceReady || !tv.isAvailable()) return null;
            Bitmap b = tv.getBitmap(960, 540);
            if (b == null) return null;
            return new Frame(b, tiny(b));
        } catch (Throwable e) {
            return null;
        }
    }

    private void releasePlayer() {
        MediaPlayer p = mp;
        mp = null;
        if (p != null) {
            try { p.release(); } catch (Exception ignored) { }
        }
    }

    /** Center-crop the video to fill the screen. */
    private void applyTransform() {
        int w = tv.getWidth(), h = tv.getHeight();
        if (vw <= 0 || vh <= 0 || w <= 0 || h <= 0) return;
        float va = (float) vw / vh, ta = (float) w / h;
        float sx = 1f, sy = 1f;
        if (ta > va) sy = ta / va; else sx = va / ta;
        Matrix m = new Matrix();
        m.setScale(sx, sy, w / 2f, h / 2f);
        tv.setTransform(m);
    }

    private boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    // ---------- auto-advance ----------

    private void scheduleAdvance(long ms) {
        ui.removeCallbacks(advanceRunnable);
        if (mode == MODE_PLAY) ui.postDelayed(advanceRunnable, ms);
    }

    private void cancelAdvance() {
        ui.removeCallbacks(advanceRunnable);
    }

    private void resumeAdvance() {
        if (current == null) return;
        scheduleAdvance(current.video ? 20000L : 12000L);
    }

    // ---------- remote control ----------

    /** Returns false when the app should quit (any button that has no role). */
    public boolean onRemoteKey(int code) {
        boolean enter = code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER
                || code == KeyEvent.KEYCODE_NUMPAD_ENTER;
        boolean up = code == KeyEvent.KEYCODE_DPAD_UP, down = code == KeyEvent.KEYCODE_DPAD_DOWN;
        boolean left = code == KeyEvent.KEYCODE_DPAD_LEFT, right = code == KeyEvent.KEYCODE_DPAD_RIGHT;
        boolean back = code == KeyEvent.KEYCODE_BACK, menu = code == KeyEvent.KEYCODE_MENU;

        switch (mode) {
            case MODE_PLAY:
                if (left) { goPrev(); return true; }
                if (right) { goNext(); return true; }
                if (back && current != null) { openMenu(); return true; }
                if (menu && current != null) { openCard(); return true; }
                return false;
            case MODE_MENU:
                if (up) { moveMenu(-1); return true; }
                if (down) { moveMenu(1); return true; }
                if (enter) { selectMenu(); return true; }
                if (back) { closePanels(); return true; }
                return left || right;
            case MODE_CONFIRM:
                if (up || left) { moveConfirm(-1); return true; }
                if (down || right) { moveConfirm(1); return true; }
                if (enter) { selectConfirm(); return true; }
                if (back) { closePanels(); return true; }
                return false;
            case MODE_CARD:
                if (back || menu || enter) { closePanels(); return true; }
                return up || down || left || right;
            default:
                return false;
        }
    }

    // ---------- panels ----------

    private Bitmap backdropBitmap() {
        if (videoOnScreen) {
            Frame s = snapshotVideo();
            return s != null ? s.tiny : null;
        }
        return currentFrame != null ? currentFrame.tiny : null;
    }

    private void showPanel(final Glass p) {
        clock.animate().cancel();
        clock.animate().alpha(0f).setDuration(200).setStartDelay(0).setInterpolator(null).start();
        sourceView.animate().cancel();
        sourceView.animate().alpha(0f).setDuration(200).setStartDelay(0).setInterpolator(null).start();
        scrim.setVisibility(VISIBLE);
        anim(scrim, 1f, 300, 0, null);
        p.setVisibility(VISIBLE);
        p.setAlpha(0f);
        p.setTranslationY(dp(22));
        p.animate().cancel();
        p.animate().alpha(1f).translationY(0f).setDuration(300).setStartDelay(0)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void hidePanel(final Glass p) {
        if (p.getVisibility() != VISIBLE) return;
        p.animate().cancel();
        p.animate().alpha(0f).translationY(dp(14)).setDuration(220).setStartDelay(0).setInterpolator(null).start();
        ui.postDelayed(new Runnable() {
            @Override public void run() { if (p.getAlpha() == 0f) p.setVisibility(GONE); }
        }, 280);
    }

    private void hidePanelsNow() {
        for (Glass p : new Glass[]{menuPanel, confirmPanel, cardPanel}) {
            p.animate().cancel();
            p.setAlpha(0f);
            p.setVisibility(GONE);
        }
        scrim.animate().cancel();
        scrim.setAlpha(0f);
        scrim.setVisibility(GONE);
        clock.setAlpha(1f);
        sourceView.setAlpha(1f);
    }

    private void closePanels() {
        hidePanel(menuPanel);
        hidePanel(confirmPanel);
        hidePanel(cardPanel);
        anim(scrim, 0f, 260, 0, null);
        ui.postDelayed(new Runnable() {
            @Override public void run() { if (scrim.getAlpha() == 0f) scrim.setVisibility(GONE); }
        }, 320);
        clock.animate().cancel();
        clock.animate().alpha(1f).setDuration(300).setStartDelay(150).setInterpolator(null).start();
        sourceView.animate().cancel();
        sourceView.animate().alpha(1f).setDuration(300).setStartDelay(150).setInterpolator(null).start();
        mode = MODE_PLAY;
        resumeAdvance();
    }

    private String counterText() {
        int p = bank.photos(), v = bank.videos(), t = p + v;
        return p + (p > 1 ? " photos" : " photo") + " · " + v + (v > 1 ? " vidéos" : " vidéo")
                + " · " + t + (t > 1 ? " médias" : " média");
    }

    // options menu

    private void openMenu() {
        mode = MODE_MENU;
        menuIndex = 0;
        cancelAdvance();
        menuRows[0].setText(current.fav ? "Retirer des favoris" : "Mettre en favori");
        styleRows(menuRows, menuIndex);
        menuCount.setText(counterText());
        menuPanel.setBackdrop(backdropBitmap());
        showPanel(menuPanel);
    }

    private void moveMenu(int d) {
        menuIndex = (menuIndex + d + 3) % 3;
        styleRows(menuRows, menuIndex);
    }

    private void selectMenu() {
        if (menuIndex == 0) toggleFavorite();
        else if (menuIndex == 1) openConfirm();
        else closePanels();
    }

    private void toggleFavorite() {
        boolean now = bank.toggleFav(current);
        closePanels();
        showToast(now ? "Ajouté aux favoris" : "Retiré des favoris");
    }

    // delete confirmation

    private void openConfirm() {
        mode = MODE_CONFIRM;
        confirmIndex = 1;   // "Annuler" is selected by default
        styleRows(confirmRows, confirmIndex);
        confirmPanel.setBackdrop(backdropBitmap());
        hidePanel(menuPanel);
        showPanel(confirmPanel);
    }

    private void moveConfirm(int d) {
        confirmIndex = (confirmIndex + d + 2) % 2;
        styleRows(confirmRows, confirmIndex);
    }

    private void selectConfirm() {
        if (confirmIndex == 0) performDelete();
        else closePanels();
    }

    private void performDelete() {
        Media m = current;
        bank.delete(m);
        cache.remove(m.src);
        for (int i = upcoming.size() - 1; i >= 0; i--) if (upcoming.get(i).src.equals(m.src)) upcoming.remove(i);
        int newPos = hpos;
        for (int i = hist.size() - 1; i >= 0; i--) {
            if (hist.get(i).src.equals(m.src)) {
                hist.remove(i);
                if (i <= hpos) newPos--;
            }
        }
        hpos = newPos;
        closePanels();
        cancelAdvance();
        showToast("Supprimé · " + counterText());
        goNext();   // dissolves into the next media, no black screen
    }

    private void showToast(String msg) {
        toast.setText(msg);
        toastGen++;
        final int g = toastGen;
        toast.animate().cancel();
        toast.setAlpha(0f);
        toast.setTranslationY(-dp(10));
        toast.animate().alpha(1f).translationY(0f).setDuration(260).setStartDelay(0)
                .setInterpolator(new DecelerateInterpolator()).start();
        ui.postDelayed(new Runnable() {
            @Override public void run() {
                if (g == toastGen) anim(toast, 0f, 380, 0, null);
            }
        }, 2400);
    }

    // description card

    private void openCard() {
        mode = MODE_CARD;
        cancelAdvance();
        final Media m = current;
        cardTitle.setText(!m.title.isEmpty() ? m.title : (m.video ? "Vidéo" : "Photo"));
        cardMeta.setText(m.source + " · " + (m.video ? "Vidéo" : "Photo") + (m.fav ? " · Favori" : ""));
        cardFoot.setText(counterText());
        cardBody.setText("Chargement de la description…");
        cardPanel.setBackdrop(backdropBitmap());
        showPanel(cardPanel);
        loadDescription(m);
    }

    private void loadDescription(final Media m) {
        Bank.Desc cached = bank.getDesc(m.src);
        if (cached != null) {
            applyDescription(m, cached.text, cached.ai);
            return;
        }
        Bitmap forAi = null;
        if (Describer.aiAvailable()) {
            if (videoOnScreen) {
                Frame s = snapshotVideo();
                if (s != null) forAi = s.full;
            } else if (currentFrame != null) {
                forAi = currentFrame.full;
            }
        }
        final Bitmap frame = forAi;
        new Thread(new Runnable() {
            @Override public void run() {
                final Describer.Result r = Describer.build(m, frame);
                if (r.cacheable) bank.putDesc(m.src, r.text, r.ai);
                ui.post(new Runnable() {
                    @Override public void run() { applyDescription(m, r.text, r.ai); }
                });
            }
        }).start();
    }

    private void applyDescription(Media m, String text, boolean ai) {
        if (mode != MODE_CARD || current != m) return;
        cardBody.setText(text);
        cardFoot.setText(counterText() + (ai ? "\nDescription générée par IA, elle peut contenir des erreurs." : ""));
    }
}
