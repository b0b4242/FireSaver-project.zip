package com.jp.firesaver;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * The screensaver itself, shared by the app screen (MainActivity) and the system dream (SaverService).
 *  1) videos in /sdcard/Android/data/com.jp.firesaver/files/ (or URLs in urls.txt) -> muted, shuffled
 *  2) otherwise -> Bing "image of the day" slideshow (slow zoom + crossfade)
 */
public class SaverView extends FrameLayout {
    private static final int PHOTO_SECONDS = 15;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final VideoView video;
    private final FrameLayout photoLayer;
    private final ImageView[] imgs = new ImageView[2];
    private int cur = 0;

    private final List<String> playlist = new ArrayList<>();
    private int index = 0;
    private int errors = 0;

    private volatile boolean running = false;
    private Thread photoThread;

    public SaverView(Context ctx) {
        super(ctx);
        setBackgroundColor(Color.BLACK);

        video = new VideoView(ctx);
        addView(video, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, Gravity.CENTER));

        photoLayer = new FrameLayout(ctx);
        for (int i = 0; i < 2; i++) {
            ImageView iv = new ImageView(ctx);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setAlpha(0f);
            photoLayer.addView(iv, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            imgs[i] = iv;
        }
        addView(photoLayer, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        photoLayer.setVisibility(View.GONE);

        TextClock clock = new TextClock(ctx);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("h:mm");
        clock.setTextColor(Color.argb(200, 255, 255, 255));
        clock.setTextSize(36);
        clock.setShadowLayer(8f, 0f, 2f, Color.BLACK);
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.START);
        lp.setMargins(80, 0, 0, 60);
        addView(clock, lp);

        video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer mp) { mp.setVolume(0f, 0f); errors = 0; }
        });
        video.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override public void onCompletion(MediaPlayer mp) { playNext(); }
        });
        video.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override public boolean onError(MediaPlayer mp, int what, int extra) {
                if (++errors <= playlist.size()) playNext();
                return true;
            }
        });
    }

    public void start() {
        loadPlaylist();
        if (!playlist.isEmpty()) {
            photoLayer.setVisibility(View.GONE);
            video.setVisibility(View.VISIBLE);
            Collections.shuffle(playlist);
            index = 0;
            play();
        } else {
            video.setVisibility(View.GONE);
            photoLayer.setVisibility(View.VISIBLE);
            startPhotos();
        }
    }

    public void stop() {
        running = false;
        if (photoThread != null) photoThread.interrupt();
        ui.removeCallbacksAndMessages(null);
        video.stopPlayback();
    }

    // ---------- Video mode ----------

    private File dir() {
        File d = getContext().getExternalFilesDir(null);
        return d != null ? d : getContext().getFilesDir();
    }

    private void loadPlaylist() {
        playlist.clear();
        File[] files = dir().listFiles();
        if (files != null) {
            for (File f : files) {
                String n = f.getName().toLowerCase();
                if (n.endsWith(".mp4") || n.endsWith(".mov") || n.endsWith(".mkv") || n.endsWith(".webm"))
                    playlist.add(Uri.fromFile(f).toString());
            }
        }
        File urls = new File(dir(), "urls.txt");
        if (urls.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(urls))) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.startsWith("http")) playlist.add(line);
                }
            } catch (Exception ignored) { }
        }
    }

    private void playNext() {
        index = (index + 1) % playlist.size();
        if (index == 0) Collections.shuffle(playlist);
        play();
    }

    private void play() {
        video.setVideoURI(Uri.parse(playlist.get(index)));
        video.start();
    }

    // ---------- Photo mode (Bing) ----------

    private void startPhotos() {
        running = true;
        photoThread = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    List<String> urls = new ArrayList<>();
                    while (running && urls.isEmpty()) {
                        urls = fetchBingUrls();
                        if (urls.isEmpty()) {
                            postMessage("Pas de connexion pour les photos Bing.\n"
                                    + "Tu peux aussi mettre des videos dans :\n" + dir().getAbsolutePath());
                            Thread.sleep(15000);
                        }
                    }
                    int i = 0;
                    while (running) {
                        final Bitmap b = download(urls.get(i % urls.size()));
                        i++;
                        if (b != null) {
                            ui.post(new Runnable() { @Override public void run() { showBitmap(b); } });
                            Thread.sleep(PHOTO_SECONDS * 1000L);
                        }
                    }
                } catch (InterruptedException ignored) { }
            }
        });
        photoThread.start();
    }

    private void postMessage(final String msg) {
        ui.post(new Runnable() {
            @Override public void run() {
                TextView t = new TextView(getContext());
                t.setText(msg);
                t.setTextColor(Color.WHITE);
                t.setTextSize(22);
                t.setGravity(Gravity.CENTER);
                addView(t, new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
            }
        });
    }

    private List<String> fetchBingUrls() {
        String[] markets = {"en-US", "fr-FR", "ja-JP", "de-DE", "en-GB", "pt-BR"};
        LinkedHashSet<String> set = new LinkedHashSet<>();
        for (String m : markets) {
            try {
                String json = httpGetString("https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=" + m);
                JSONArray arr = new JSONObject(json).getJSONArray("images");
                for (int i = 0; i < arr.length(); i++) {
                    String base = arr.getJSONObject(i).getString("urlbase");
                    set.add("https://www.bing.com" + base + "_1920x1080.jpg");
                }
            } catch (Exception ignored) { }
        }
        List<String> out = new ArrayList<>(set);
        Collections.shuffle(out);
        return out;
    }

    private String httpGetString(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    private Bitmap download(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(15000);
            try (InputStream in = c.getInputStream()) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inPreferredConfig = Bitmap.Config.RGB_565;
                return BitmapFactory.decodeStream(in, null, o);
            } finally {
                c.disconnect();
            }
        } catch (Exception e) {
            return null;
        }
    }

    private void showBitmap(Bitmap b) {
        ImageView next = imgs[1 - cur];
        ImageView prev = imgs[cur];
        next.setImageBitmap(b);
        next.setAlpha(0f);
        next.setScaleX(1f);
        next.setScaleY(1f);
        next.bringToFront();
        next.animate().alpha(1f).setDuration(1500).start();
        long zoomMs = (PHOTO_SECONDS + 3) * 1000L;
        ObjectAnimator sx = ObjectAnimator.ofFloat(next, "scaleX", 1f, 1.1f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(next, "scaleY", 1f, 1.1f);
        sx.setDuration(zoomMs); sy.setDuration(zoomMs);
        sx.setInterpolator(new LinearInterpolator());
        sy.setInterpolator(new LinearInterpolator());
        sx.start(); sy.start();
        prev.animate().alpha(0f).setDuration(1500).start();
        cur = 1 - cur;
    }
}
