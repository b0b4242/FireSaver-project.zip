package com.jp.firesaver;

/** One photo or video of the bank. */
final class Media {
    final String src;      // direct URL of the photo / video
    final boolean video;
    final String source;   // Bing, Pixabay, NASA, Wikimedia Commons, Internet Archive
    String title = "";
    String desc = "";      // original description given by the source (may be empty)
    String tags = "";
    long added;
    int fails;
    boolean fav;

    Media(String src, boolean video, String source) {
        this.src = src;
        this.video = video;
        this.source = source;
        this.added = System.currentTimeMillis();
    }
}
