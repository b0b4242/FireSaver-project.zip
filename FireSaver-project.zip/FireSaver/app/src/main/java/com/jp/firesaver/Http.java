package com.jp.firesaver;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

final class Http {
    static final String UA = "FireSaver/1.0 (personal screensaver; https://github.com/b0b4242/FireSaver-project.zip)";

    static final class Result {
        final byte[] data;
        final int code;   // HTTP code, 0 = network problem / too big
        Result(byte[] data, int code) { this.data = data; this.code = code; }
    }

    static Result get(String url, int maxBytes) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(20000);
            c.setRequestProperty("User-Agent", UA);
            int code = c.getResponseCode();
            if (code >= 400) return new Result(null, code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) {
                    bos.write(buf, 0, n);
                    if (bos.size() > maxBytes) return new Result(null, 0);
                }
                return new Result(bos.toByteArray(), code);
            }
        } catch (Exception e) {
            return new Result(null, 0);
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static String getString(String url) throws Exception {
        Result r = get(url, 5 * 1024 * 1024);
        if (r.data == null) throw new Exception("http " + r.code);
        return new String(r.data, "UTF-8");
    }

    static String postJson(String url, String json, String apiKey) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(10000);
            c.setReadTimeout(40000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("x-goog-api-key", apiKey);
            try (OutputStream out = c.getOutputStream()) {
                out.write(json.getBytes("UTF-8"));
            }
            int code = c.getResponseCode();
            if (code >= 400) throw new Exception("http " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                return bos.toString("UTF-8");
            }
        } finally {
            c.disconnect();
        }
    }
}
