package com.jp.firesaver;

final class SecretKeys {
    static final String GEMINI = "";
}
